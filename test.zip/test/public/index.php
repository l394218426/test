<?php
static $_db = NULL;//数据库静态变量
define("APPLICATION_PATH",  realpath(dirname(__FILE__) . '/../'));

$application = new Yaf_Application( APPLICATION_PATH . "/conf/application.ini");
$application->bootstrap()->run();
