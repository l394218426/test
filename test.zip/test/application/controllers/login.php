<?php

 
class LoginController extends BaseController {


	public function IndexAction($ids,$sort) 
	{

		var_dump($ids.$sort);die;
		$user = new UserModel();


		$res = $user->select('*');
		$this->getView()->assign(['data'=>$res]);
		$this->display('index');
	}

	//登陆
	public function LoginAction()
	{

		if($_POST !== [])
		{
			
			$user = new UserModel();
			$data = $_POST;
			$name = isset($data['user_name']) ? $data['user_name'] : "";
			$pwd = isset($data['user_pwd']) ? $data['user_pwd'] : '';
			if($name=='' || $pwd=='')
			{

				echo "<script>alert('账号密码不能为空');location.href='login'</script>";die;
			}
			$pwd = md5($pwd);
			$where['user_name'] = $name;
			$res = $user->select(["user_pwd","user_name"],$where);
			var_dump($res);die;
			if($res==[])
			{

				echo "<script>alert('账号不存在');location.href='login'</script>";die;
			}

			if($res['user_name'] == $name && $res['user_pwd'] == $pwd)
			{

				echo "<script>alert('登陆成功');location.href='login/index'</script>";die;
			}
			else
			{

				echo "<script>alert('登陆失败');location.href='login'</script>";die;	
			}
		}
		else
		{

			$this->display('login');
		}
	} 

	//注册
	public function RegisterAction()
	{

		$user = new UserModel();
		if($_POST !== [])
		{
			$data = $_POST;
			$data['user_pwd'] = md5($data['user_pwd']);
			if($data['user_name'] == '' || $data['user_pwd'] == '')
			{

				echo "<script>alert('账号或者密码不能为空');location.href='register'</script>";die;
			}
			$where['user_name'] = $data['user_name'];
			$res = $user->findOne($where);
			if($res!=[])
			{

				echo "<script>alert('该账号存在');location.href='register'</script>";die;
			}
			if($user->add($data))
			{
				
				echo "<script>alert('注册成功');location.href='index'</script>";die;	
			}
			else
			{
				echo "<script>alert('注册失败');location.href='register'</script>";die;
			}
			
		}
		else
		{


			$this->render('register');
		}
	}
}
