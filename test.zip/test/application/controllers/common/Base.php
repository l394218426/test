<?php 

/**
*   基层
*/
class BaseController extends  Yaf_Controller_Abstract
{
    public $response;
    public $token='l394218426';
    public $randNumber='666&1321assdasdsads';
    public $strTime;
	
    private function init()
	{

	}

	public function curlQuery($url,$type="get",$data = [])
 	{
 		$ch = curl_init();
        
        curl_setopt($ch,CURLOPT_URL,$url);
        //是否直接输出，默认输出 0，1 不输出
        curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
        //是否输出头信息   0：不输出          
        curl_setopt($ch,CURLOPT_HEADER,0);       
        //模拟浏览器信息           
        curl_setopt($ch,CURLOPT_USERAGENT,$_SERVER['HTTP_USER_AGENT']);
        //绕过https请求认证
        curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,0);
        
        //curl_setopt($ch,CURLOPT_CERTINFO,1);//模拟https证书
        
        //最长请求时间
        curl_setopt($ch,CURLOPT_TIMEOUT,10);
        //跟随重定向
        curl_setopt($ch,CURLOPT_FOLLOWLOCATION,1);
        
        if($type == 'post') {
            //post请求
            curl_setopt($ch, CURLOPT_POST, 1);

            if (is_array($data)) {
                //post请求数据
                curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
            } else {
                curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
            }
        }
        //执行
        $info = curl_exec($ch);
        //错误信息
        $error = curl_error($ch);
        if($error){
            //错误码
            $erron  = curl_errno($ch);
            return $erron.':'.$error;
        }
        curl_close($ch);
        return $info;
 	}



 	//post 接值
 	public function post($data='',$default="")
 	{
 		if($data == '')
 		{

 			$post = $this->getRequest()->getPost();
 		}
 		else
 		{

 			$post = $this->getRequest()->getPost($data,$default);
 		}

 		return $post; 
 	}


 	
 	//get 接值
 		public function get($data='',$default="")
 	{
 		if($data == '')
 		{

 			$get = $this->getRequest()->getQuery();
 		}
 		else
 		{

 			$get = $this->getRequest()->getQuery($data,$default);
 		}

 		return $get; 
 	}

 	

 	//判断是否是 GET 请求
 	public function isGet()
 	{

 		return $this->getRequest()->isGet();
 	}



 	//判断是否 是 post 请求
 	public function isPost()
 	{

		return $this->getRequest()->isPost();
 	}


 	//session 
 	public static function session($sessionDataName='',$data = [])
 	{

 		$session = Yaf_Session::getInstance(); 
        
 	
 		if($data!=[] )
 		{

 			$session = $session->set($sessionDataName,$data);
 		}
 		return $session; 
 	}

    //删除session
    public function Closesession()
    {
        
        $session = $this->session();

        session_destroy();
    }

    //分页
    public function Page($user,$page,$userName,$sizes = 2,$join=[])
    {


            $len = $user->count($userName);

            $size = $sizes;

            $limit = ($page-1)*$size;

            $count = ceil($len/$size);

            if($page <= 0 || $page > $count)
            {
             
                echo "<script>alert('骚年 不能在点了');history.go(-1)</script>";die;
            }
                

            if($join !=[] )
            {

                $res['data'] = $user->select($join,'*',["LIMIT"=>[$limit,$size]]); 
            }
            else
            {

                $res['data'] = $user->select('*',["LIMIT"=>[$limit,$size]]); 
            } 
      

            $res['count'] = $count;
            
            $res['page'] = $page;

            return $res;
    }



    //跳转
    public function AlertJump($msg,$url,$modules='api',$action='detail')
    {

        
        echo "<script>alert('$msg');history.go(-1)</script>";
    }
    

    // //登陆
    // public  function login_do($data,$model)
    // {
    //         $name$data['user_name'];

    // } 
}
