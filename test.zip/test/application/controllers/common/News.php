<?php 
class NewsController extends Yaf_Controller_Abstract { 


	public function detailAction($id = 0,$sort = '') { 

		print_r($this->getRequest()->getParams()); echo 'News Detail:'.$id.',sort:'.$sort; 
	} 
} 

