<?php  
class Encrpty 
{

		public $key;
		public $iv;	

	public function __construct($key,$iv)
	{
		$this->key = $key; 
		$this->iv = $iv;
	}


	//加密
	public function encrypt($data)
    {

        $this->iv=substr($this->iv,0,16);

       $res = openssl_encrypt(serialize($data),'AES-256-CBC',$this->key,0,$this->iv);

       return $res;

     }

     //解密
     public function decrypt($data)
     {
         $this->iv=substr($this->iv,0,16);
         $res = unserialize(openssl_decrypt($data,'AES-256-CBC',$this->key,0,$this->iv));

        return $res;
     }


}