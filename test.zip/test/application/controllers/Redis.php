<?php  

/**
* 
*/
class RedisController extends BaseController
{
	
	public function init()
	{

	}

	//登陆
	public function LoginAction()
	{	
		$log = new UserLogModel();
		if($this->isPost())
		{

			$User = new UserModel();

			$name = $this->post('user_name',"");
		
			$pwd = md5($this->post('user_pwd'));
			//判断输入用户名是否存在
			if($name == "")
			{

				$this->Jump('请输入账号或者密码','login');
			}
				$where['user_name'] = $name;

			//通过用户名。查询账号是否存在
			$res = $User->get('*',$where);

			if($res=='')
			{

				$this->Jump('该账号不存在','login');die;
			}

			if($res['user_name'] == $name && $res['user_pwd'] == $pwd)
			{

				//存入session
				$this->session('data',$res);
				$data['user_id'] = $res['user_id'];
				$data['log_time'] = time();
				$data['log_operation'] = "登陆成功";
				$log->insert($data);
			
				$this->Jump('登陆成功','index');
			}
			else
			{
				
				$data['user_id'] = $res['user_id'];
				$data['log_time'] = time();
				$data['log_operation'] = "登陆失败";
				$log->insert($data);
				$this->Jump('登陆失败','login');
			}


		}
		else
		{

			$this->display('login');
		}
	}

	//首页
	public function IndexAction()
	{

		$goods = new GoodsModel;

		$where['is_rush'] = 1;
		
		$res['data'] = $goods->get('*',$where);

		$this->display('index',$res);
	}

	//生成订单页面
	public function RushAction()
	{
		$order = new QorderModel();
		$log = new UserLogModel();
		$goods = new GoodsModel;
		$session = $this->session();
		// $redis = new redis();
	 //    $redis->connect('127.0.0.1',6379); 
	 //    $redis->flushall();
		// $redis->set('data',$data);
		// $ping = $redis->get('data');
	 //    $data = $this->post();
		if(!isset($data['goods_id']))
		{

			$this->Jump('请选择您要抢购的商品','index');die;
		}

		

		//mysql 抢购
		$i=0;
		while ($i<=20) {
			//查询商品为1 的库存
			$res = $goods->get('*',['goods_id'=>$this->post('goods_id')]);
			//如果库存为0 ，则不能抢购.
			if($res['goods_num']<=0)
			{
			
			$this->Jump('抱歉商品已被抢完','index');break;
			
			}
			$arr['goods_num'] = $res['goods_num'] - $data['goods_num']; 
			$where['goods_num'] = $res['goods_num'];
			$where['goods_id'] = $data['goods_id'];
			$res = $goods->update($arr,$where);
			if($res)
			{
				break;
			}
			$i++;
		}
	  //   if($res['goods_num']==$this->post('goods_num'))
	  //   {
	  //   	for ($i=1; $i <=$res['goods_num']; $i++) { 
		
			// $resu = $redis->lpush('goods_num',$i);
			// };
	  //   }
		

		
		$arr['user_id'] = $session['data']['user_id'];
		$arr['create_time'] = time();
		$yCode = array('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J');
		$orderSn = $yCode[intval(date('Y')) - 2011] . strtoupper(dechex(date('m'))) . date('d') . substr(time(), -5) . substr(microtime(), 2, 5) . sprintf('%02d', rand(0, 99));
		$arr['order_num'] = $orderSn;
		$array = array_merge($arr,$data);
			// $rush = $redis->lpop('goods_num');
			// if($rush=='')
			// {
			// 	$this->Jump('抱歉该商品已被抢购一空','index');die;
			// }
		$result = $order->insert($array);

		if($result)
		{	
			

			
				// $data['goods_num'] = $res['goods_num']-1;
				// $where['goods_id'] = $data['goods_id']; 
				$userlog['user_id'] = $arr['user_id'];
				$userlog['log_time'] = time();
				$userlog['log_operation'] = "抢购成功";
				$log->insert($userlog);
				// $goods->update($data,$where);
			$this->Jump('抢购成功，请您立即付款','index');

		}
		else
		{	

				$userlog['user_id'] = $arr['user_id'];
				$userlog['log_time'] = time();
				$userlog['log_operation'] = "抢购失败";
				$log->insert($userlog);

			$this->Jump('您的网络连接出现问题，请稍后重试','index');
		}
	}

	private function Jump($msg,$url)
	{

	echo "<script>alert('$msg');location.href='?c=redis&a={$url}&m=index'</script>";
	} 

}
