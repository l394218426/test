<?php 
/**
* 
*/
class CollectionController extends Yaf_Controller_Abstract
{
	
	 public function init()
	 {
		
	 }


	 public function IndexAction()
	 {

	 	$csdn = new CsdnModel();
	 	$csdnC = new CsdnCateModel();
	 	$url = "D:\phpstudy/WWW/test/application/views/csdn.php";
        
        //正则分类
        $check = "#".
          '<li class=".*"><a href=".*">(.*)</a></li>\s+'.
          "#Ui";


        //正则标题
        $title = '#'.
       		'<div class="title">\s+'.
       		'<h2 class="csdn-tracking-statistics" data-mod="popu_459" data-poputype="feed" data-feed-show="false" data-dsm="post">\s+'.
       		'<a strategy=".*" href=".*" target="_blank">\s+'.
       		'(.*)\s+</a>\s+'.
       		'</h2>\s+#Ui';

        //正则作者
        $user = '#'.
        	'<dd class="name">\s+'.
        	'\s+<a href=".*" target="_blank">\s+'.
        	'(.*)\s+</a>\s+'.
        	'</dd>#Ui';

        //正则时间
        $date = '#'.
       		'<div class="interval"></div>\s+'.
              '<dd class="time">\s+'.
                '(.*)\s+</dd>#Ui';
  
        //分类
        $cate = $this->preg($url,$check);
        
        if($cate!=false){

        	$cc = $cate;
        }
        else
        {

        	die("匹配失败");
        }

        //标题
 		$h1 = $this->preg($url,$title);      
        
        if($h1!=false)
        {

        	$data['title'] = $h1;
        }
        else
        {

        	die("匹配失败");
        }
    
        
        //作者
        $author = $this->preg($url,$user);

        if($author != false)
        {
        	$data['author'] = $author;
        }
        else
        {

        	die("匹配失败");
        }

        //时间
        $time = $this->preg($url,$date);

        if($time != false)
        {
        	$data['time'] = $time;
        }
        else
        {

        	die("匹配失败");
        }
        var_dump($cc);die;
   //  		foreach ($cc as $key => $value) {
			// 		$cat[]['csdn_name'] = $value;
   //  		}
 		// $res = $csdnC->insert($cat);
   //  	if($res)
   //  	{
   //  		echo "1";
   //  	}else
   //  	{
   //  		echo '2';
   //  	}
        $len = count($data['time'])-1;
 				foreach ($data as $key => $value) {

 				}die;
      
        	for ($i=0; $i <=$len ; $i++) { 
   					$arr[$i]['author'] = ltrim($data['author'][$i],"");
   					$arr[$i]["title"] =  ltrim($data['title'][$i],"");
   					$arr[$i]['time'] =  ltrim($data['time'][$i],"");
        	 } 
        		var_dump($arr);die;
        	if($csdn->insert($arr))
        	{
        		echo 1;
        	}
        	else
        	{
        		echo 0;
        	}
        


	 }

	 public function Preg($url,$check)
	 {
	 	$html = file_get_contents("$url");

	 	$res = preg_match_all($check,$html,$arr);

	 	if($arr[1] == [])
	 	{
	 		return false;
	 	}
	 	else
	 	{
	 		return $arr[1];
	 	}
	 }
}
