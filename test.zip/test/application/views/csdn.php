
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="referrer"content="always">
    <meta name="msvalidate.01" content="3189512127C34C46BC74BED5852D45E4" />
    <title>CSDN-专业IT技术社区</title>
    <script src='/js/tingyun-rum-feed.js?v=20180509' type='text/javascript'></script>
    <link ref="canonical"  href="https://www.csdn.net/">
    <link href="//csdnimg.cn/public/favicon.ico" rel="SHORTCUT ICON">
    <script src="//csdnimg.cn/public/common/libs/jquery/jquery-1.9.1.min.js" type="text/javascript"></script>
    <script src="//csdnimg.cn/pubfooter/js/tracking-1.0.2.js" type="text/javascript" charset="utf-8"></script>
    <script src="//csdnimg.cn/rabbit/exposure-click/main_flume.js?v1.15.35"></script> 
    <link rel="stylesheet" href="//csdnimg.cn/public/common/toolbar/content_toolbar_css/content_toolbar.css">
    <link rel="stylesheet" href="//csdnimg.cn/public/common/libs/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="//csdnimg.cn/public/static/css/avatar.css">
    <link href='/css/csdn_feed.css?1525868485' rel='stylesheet' />
    <script src='/js/modernizr.js?1506677690' type='text/javascript'></script>
</head>
<body data-category="home" data-host_type="www">
    <script id="toolbar-tpl-scriptId" prod="download" skin="black" src="//csdnimg.cn/public/common/toolbar/js/content_toolbar.js" type="text/javascript" domain="http://blog.csdn.net"></script>
    <div class="container clearfix">
      <nav id="nav" class="clearfix">
        <div class="clearfix">
        <div class="nav_com">
          <ul>
                  <li class="active"><a href="/">推荐</a></li>
                                  <li class=""><a href="/nav/newarticles">最新文章</a></li>
                                        <li class=""><a href="/nav/watchers">关注</a></li>
                                        <li class=""><a href="/nav/news">资讯</a></li>
                                        <li class=""><a href="/nav/ai">人工智能</a></li>
                                      <li class=""><a href="/nav/cloud">云计算/大数据</a></li>
                                        <li class=""><a href="/nav/blockchain">区块链</a></li>
                                        <li class=""><a href="/nav/db">数据库</a></li>
                                        <li class=""><a href="/nav/career">程序人生</a></li>
                                        <li class=""><a href="/nav/game">游戏开发</a></li>
                                    <li class=""><a href="/nav/engineering">研发管理</a></li>
                                        <li class=""><a href="/nav/web">前端</a></li>
                                        <li class=""><a href="/nav/mobile">移动开发</a></li>
                                        <li class=""><a href="/nav/iot">物联网</a></li>
                                        <li class=""><a href="/nav/ops">运维</a></li>
                                        <li class=""><a href="/nav/fund">计算机基础</a></li>
                                        <li class=""><a href="/nav/lang">编程语言</a></li>
                                        <li class=""><a href="/nav/arch">架构</a></li>
                                        <li class=""><a href="/nav/avi">音视频开发</a></li>
                                        <li class=""><a href="/nav/sec">安全</a></li>
                                        <li class=""><a href="/nav/other">其他</a></li>
                                </ul>

        </div>
    </div>
</nav>
      <div class="fixed_content">
            <!--头部banner广告 begin-->
    <div class="banner-ad-box">
        <ins data-revive-zoneid="281" data-revive-id="8c38e720de1c90a6f6ff52f3f89c4d57"></ins>
        <ins data-revive-zoneid="282" data-revive-id="8c38e720de1c90a6f6ff52f3f89c4d57"></ins>
    </div>
    <!--头部banner广告 end-->
    <main>
        <!DOCTYPE html>
 <div class="carousel">
    <div class="carousel-left">
        <div id="myCarousel" class="slide" data-ride="carousel">
      <!-- Indicators -->
      <ol class="carousel-indicators">
						<li data-target="#myCarousel" data-slide-to="0" class="active"></li>
					<li data-target="#myCarousel" data-slide-to="1" class=""></li>
					<li data-target="#myCarousel" data-slide-to="2" class=""></li>
					<li data-target="#myCarousel" data-slide-to="3" class=""></li>
					<li data-target="#myCarousel" data-slide-to="4" class=""></li>
			      </ol>
      <div class="carousel-inner" role="listbox">
	            	         
		<div class="carousel-item csdn-tracking-statistics active" data-mod="popu_465" data-dsm="post">
			<a href="https://blog.csdn.net/blockchain_lemon/article/details/80276291" target="_blank">
				<img src="//csdnimg.cn/feed/20180511/0eb848c00582a94699055c6d7d4dc38b.png">
			</a>
			<a href="https://blog.csdn.net/blockchain_lemon/article/details/80276291" target="_blank">
				<div class="carousel-caption">
					谁说高颜值女神做不了技术？她偏做，还是百万级主链！				</div>
			</a>
			<a href="https://blog.csdn.net/blockchain_lemon/article/details/80276291" target="_blank" style="display:block;">
				<div class='cover'></div>
			</a>
		</div>
	    	         
		<div class="carousel-item csdn-tracking-statistics " data-mod="popu_465" data-dsm="post">
			<a href="https://blog.csdn.net/csdnnews/article/details/80268716" target="_blank">
				<img src="//csdnimg.cn/feed/20180511/cc0f9aab6d75078eafc6e01b7d4b81c3.png">
			</a>
			<a href="https://blog.csdn.net/csdnnews/article/details/80268716" target="_blank">
				<div class="carousel-caption">
					独家 | 微软披露拓扑量子计算机计划！				</div>
			</a>
			<a href="https://blog.csdn.net/csdnnews/article/details/80268716" target="_blank" style="display:block;">
				<div class='cover'></div>
			</a>
		</div>
	    	         
		<div class="carousel-item csdn-tracking-statistics " data-mod="popu_465" data-dsm="post">
			<a href="https://blog.csdn.net/csdnsevenn/article/details/80176306" target="_blank">
				<img src="//csdnimg.cn/feed/20180511/9129305e1271f38529456edb88803c1f.png">
			</a>
			<a href="https://blog.csdn.net/csdnsevenn/article/details/80176306" target="_blank">
				<div class="carousel-caption">
					别人问我：为什么程序员都不善言辞？惭愧啊！				</div>
			</a>
			<a href="https://blog.csdn.net/csdnsevenn/article/details/80176306" target="_blank" style="display:block;">
				<div class='cover'></div>
			</a>
		</div>
	    	         
		<div class="carousel-item csdn-tracking-statistics " data-mod="popu_465" data-dsm="post">
			<a href="https://blog.csdn.net/dQCFKyQDXYm3F8rB0/article/details/80272448" target="_blank">
				<img src="//csdnimg.cn/feed/20180510/ca20de782dc6518a30d846f68dd823a9.jpg">
			</a>
			<a href="https://blog.csdn.net/dQCFKyQDXYm3F8rB0/article/details/80272448" target="_blank">
				<div class="carousel-caption">
					又一名逃犯在张学友演唱会被 AI 捕获，人送绰号“热心歌神张先生”				</div>
			</a>
			<a href="https://blog.csdn.net/dQCFKyQDXYm3F8rB0/article/details/80272448" target="_blank" style="display:block;">
				<div class='cover'></div>
			</a>
		</div>
	    	         
		<div class="carousel-item csdn-tracking-statistics " data-mod="popu_465" data-dsm="post">
			<a href="http://g.csdn.net/5297799" target="_blank">
				<img src="//csdnimg.cn/feed/20180510/5ae659d09e698622ae51f40d8c8db954.jpg">
			</a>
			<a href="http://g.csdn.net/5297799" target="_blank">
				<div class="carousel-caption">
					入行 AI，如何选个脚踏实地的岗位？				</div>
			</a>
			<a href="http://g.csdn.net/5297799" target="_blank" style="display:block;">
				<div class='cover'></div>
			</a>
		</div>
	    	      </div>
      <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
        <span class="glyphicon" aria-hidden="true">
			<svg viewBox="0 0 19 30">
				<path d="M18,5L7,16l11,11l-3,3L1,16L15,2L18,5z"/>
			</svg>
		</span>
        <span class="sr-only">Previous</span>
      </a>
      <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
        <span class="glyphicon" aria-hidden="true">
			<svg viewBox="0 0 19 30">
				<path d="M4,1l14,14L4,29l-3-3l11-11L1,4L4,1z"/>
			</svg>
		</span>
        <span class="sr-only">Next</span>
      </a>
    </div><!-- /.carousel -->
    </div>
    <div class="carousel-right">
    				        <div class="carousel-right-u csdn-tracking-statistics" data-mod="popu_616" data-dsm="post">
	            <a href="https://blog.csdn.net/heyc861221/article/details/80276177" target="_blank">
	                <img src="//csdnimg.cn/feed/20180511/d27d75dd533a41c07255541896daff43.jpg"/>
	            </a>
	            <a href="https://blog.csdn.net/heyc861221/article/details/80276177" target="_blank">
                <p class="carousel-right-caption">
      						<span>大四学生整理：一份“不完美”的数据科学问答清单</span>
      					</p>
	            </a>
				<a href="https://blog.csdn.net/heyc861221/article/details/80276177" target="_blank" style="display:block;">
					<div class='cover'></div>
				</a>
	        </div>
				        <div class="carousel-right-u csdn-tracking-statistics" data-mod="popu_616" data-dsm="post">
	            <a href="https://blog.csdn.net/csdnnews/article/details/80268776" target="_blank">
	                <img src="//csdnimg.cn/feed/20180511/e680b8795abc3abc71bb54dd96f73b9d.png"/>
	            </a>
	            <a href="https://blog.csdn.net/csdnnews/article/details/80268776" target="_blank">
                <p class="carousel-right-caption">
      						<span>微软 VS Code 或将取代 Visual Studio！</span>
      					</p>
	            </a>
				<a href="https://blog.csdn.net/csdnnews/article/details/80268776" target="_blank" style="display:block;">
					<div class='cover'></div>
				</a>
	        </div>
			            </div>
</div>
                    <div class="feed-loading-box">
    <div class="loader-inner ball-clip-rotate-pulse">
        <div></div>
    </div>
    <span class="loading-txt">在奔跑中</span>
</div>
<div>
    <div class="msg-tooltip">
        <div class="update_counts"></div>
    </div>
</div>
<div class="feed-fix-box">
    <div class="scroll-fixbar clearfix csdn-tracking-statistics" data-mod="popu_463" data-dsm="post">
        <a class="txt txt-refrash-new">您有新的推荐内容，点击查看</a>
        <button class="btn btn-nobg-noborder btn-nobg-noborder btn-close-fixbar">
            <i class="icon-close"></i>
        </button>
    </div>
</div>
<ul class="feedlist_mod home" id="feedlist_id" shown-offset="1526258960900022">
                    <li class="clearfix" data-type="top" data-id="80207169" shown-time="1526258960">
      <div class="list_con">
        <div class="title">
          <h2 class="csdn-tracking-statistics" data-mod="popu_459" data-poputype="feed" data-feed-show="false" data-dsm="post">
              <a strategy="top" href="http://blog.csdn.net/blogdevteam/article/details/80207169" target="_blank">
                  程序猿的正确提问方式              </a>
          </h2>
                    <div class="close_tag">
              <div class="unin_reason_dialog_wrapper">
                  <i class="icon-close"></i>
                  <div class="unin_reason_dialog">
                      <h3>选择理由，精准屏蔽</h3>
                      <ul>
                                                    <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a>推荐不准: 运营精选</a>
                          </li>
                          <br/>
                                                    <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a> 旧闻、重复 </a>
                          </li>
                          <br/>
                          <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a> 内容质量差 </a>
                          </li>
                          <br/>
                      </ul>
                  </div>
              </div>
          </div>
                  </div> 
        <div class="summary oneline">
          从小老师就教育我们&ldquo;不懂就问&rdquo;；父母也教育我们不要不懂装懂。于是我们开始了提问，奈何会出现问了问题无人回答的尴尬局面。

看了一篇博客，在评论区问了个问题，无人回应；又或者遇到一个比较棘手的问题，在问答网站上提了个问题，却长时间无人回答。

这是一种什么体验？心酸，难受，会不会想到厕所哭一会儿？ 


这时候你苦恼的是怎样才能快速联系上作者或是找到答主，哪怕是付费也可以。 


回答者同样是希望提...        </div>
          <dl class="list_userbar">

              <dt>
                  <a href="http://blog.csdn.net/blogdevteam" target="_blank" class="user_img">
                      <img src="//avatar.csdn.net/8/C/E/1_blogdevteam.jpg" alt="blogdevteam" title="blogdevteam">
                  </a>
              </dt>
              <dd class="name">
                  <a href="http://blog.csdn.net/blogdevteam" target="_blank">
                      CSDN官方博客                  </a>
              </dd>
              <div class="interval"></div>
              <dd class="time">
                8天前              </dd>
              
              <div class="interactive floatR">
                <!--阅读 begin-->
                <dd class="read_num">
                  <a href="http://blog.csdn.net/blogdevteam/article/details/80207169">
                    <span class="num">14672</span>
                    <span class="text">阅读</span>
                  </a>
                </dd>
                <!--阅读 end-->
                
                <!--新增评论数+阅读 begin-->
                <div class="interval"></div>
                <dd class="common_num csdn-tracking-statistics tracking-click" data-poputype="feed" data-mod="popu_459">
                    <a strategy="top" href="http://blog.csdn.net/blogdevteam/article/details/80207169#comment_form" target="_blank">
                                                <span class="num">69</span> <span class="text">评论</span>
                    </a>
                </dd>
                <!--新增评论数+阅读 end-->
              </div>
          </dl>
                    <div class="is_top"></div>
                </div>
    </li>
                <li class="clearfix" data-type="blog" data-id="80165680" shown-time="1526258961">
      <div class="list_con">
        <div class="title">
          <h2 class="csdn-tracking-statistics" data-mod="popu_459" data-poputype="feed" data-feed-show="false" data-dsm="post">
              <a strategy="recommend" href="http://blog.csdn.net/qq_15071263/article/details/80165680" target="_blank">
                  Springboot @Async 异步方法              </a>
          </h2>
                    <div class="close_tag">
              <div class="unin_reason_dialog_wrapper">
                  <i class="icon-close"></i>
                  <div class="unin_reason_dialog">
                      <h3>选择理由，精准屏蔽</h3>
                      <ul>
                                                    <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a>推荐不准: 运营精选</a>
                          </li>
                          <br/>
                                                    <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a> 旧闻、重复 </a>
                          </li>
                          <br/>
                          <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a> 内容质量差 </a>
                          </li>
                          <br/>
                      </ul>
                  </div>
              </div>
          </div>
                  </div> 
        <div class="summary oneline">
          Springboot @Async 异步方法



1.异步调用

异步调用就是在不阻塞主线程的情况下执行高耗时方法

2.常规异步

通过开启新线程实现

3.在Springboot中启用异步方法

需要4个注解


@EnableAsync   开启异步
@Component  注册异步组件
@Async 标注异步方法
@Autowired 注入异步组件


4.进行一次异步调用


首先在一...        </div>
          <dl class="list_userbar">

              <dt>
                  <a href="http://blog.csdn.net/qq_15071263" target="_blank" class="user_img">
                      <img src="//avatar.csdn.net/C/F/C/1_qq_15071263.jpg" alt="qq_15071263" title="qq_15071263">
                  </a>
              </dt>
              <dd class="name">
                  <a href="http://blog.csdn.net/qq_15071263" target="_blank">
                      简简单单OnlineZuozuo                  </a>
              </dd>
              <div class="interval"></div>
              <dd class="time">
                05月02日              </dd>
              
              <div class="interactive floatR">
                <!--阅读 begin-->
                <dd class="read_num">
                  <a href="http://blog.csdn.net/qq_15071263/article/details/80165680">
                    <span class="num">2878</span>
                    <span class="text">阅读</span>
                  </a>
                </dd>
                <!--阅读 end-->
                
                <!--新增评论数+阅读 begin-->
                <div class="interval"></div>
                <dd class="common_num csdn-tracking-statistics tracking-click" data-poputype="feed" data-mod="popu_459">
                    <a strategy="recommend" href="http://blog.csdn.net/qq_15071263/article/details/80165680#comment_form" target="_blank">
                                                <span class="num">2</span> <span class="text">评论</span>
                    </a>
                </dd>
                <!--新增评论数+阅读 end-->
              </div>
          </dl>
                </div>
    </li>
        <ins data-revive-zoneid='259' data-revive-id='8c38e720de1c90a6f6ff52f3f89c4d57'></ins></ins>        <li class="clearfix" data-type="blog" data-id="80276562" shown-time="1526258961">
      <div class="list_con">
        <div class="title">
          <h2 class="csdn-tracking-statistics" data-mod="popu_459" data-poputype="feed" data-feed-show="false" data-dsm="post">
              <a strategy="wechat" href="http://blog.csdn.net/eo63y6pKI42Ilxr/article/details/80276562" target="_blank">
                  510阿里日，马老师献上最走心、最科技范儿证婚词～              </a>
          </h2>
                    <div class="close_tag">
              <div class="unin_reason_dialog_wrapper">
                  <i class="icon-close"></i>
                  <div class="unin_reason_dialog">
                      <h3>选择理由，精准屏蔽</h3>
                      <ul>
                                                    <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a>推荐不准: 业界最新</a>
                          </li>
                          <br/>
                                                    <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a> 旧闻、重复 </a>
                          </li>
                          <br/>
                          <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a> 内容质量差 </a>
                          </li>
                          <br/>
                      </ul>
                  </div>
              </div>
          </div>
                  </div> 
        <div class="summary oneline">
          510阿里日，102对新人在马爸爸的见证下，步入AI时代~马老师献上最走心、最切题、最科技范儿也最情深义重的证婚词：在早上的亲友见面会环节上，一位员工家属就向阿里CPO童...        </div>
          <dl class="list_userbar">

              <dt>
                  <a href="http://blog.csdn.net/eo63y6pKI42Ilxr" target="_blank" class="user_img">
                      <img src="//avatar.csdn.net/2/8/6/1_eo63y6pki42ilxr.jpg" alt="eo63y6pKI42Ilxr" title="eo63y6pKI42Ilxr">
                  </a>
              </dt>
              <dd class="name">
                  <a href="http://blog.csdn.net/eo63y6pKI42Ilxr" target="_blank">
                      云栖社区v                  </a>
              </dd>
              <div class="interval"></div>
              <dd class="time">
                2天前              </dd>
                                <div class="interval"></div>
                  <dd class="tag">
                      <a href="/nav/career" target="_blank">
                          程序人生                      </a>
                  </dd>
              
              <div class="interactive floatR">
                <!--阅读 begin-->
                <dd class="read_num">
                  <a href="http://blog.csdn.net/eo63y6pKI42Ilxr/article/details/80276562">
                    <span class="num">778</span>
                    <span class="text">阅读</span>
                  </a>
                </dd>
                <!--阅读 end-->
                
                <!--新增评论数+阅读 begin-->
                <div class="interval"></div>
                <dd class="common_num csdn-tracking-statistics tracking-click" data-poputype="feed" data-mod="popu_459">
                    <a strategy="wechat" href="http://blog.csdn.net/eo63y6pKI42Ilxr/article/details/80276562#comment_form" target="_blank">
                                                <span class="num">1</span> <span class="text">评论</span>
                    </a>
                </dd>
                <!--新增评论数+阅读 end-->
              </div>
          </dl>
                </div>
    </li>
                <li class="clearfix" data-type="blog" data-id="80276245" shown-time="1526258961">
      <div class="list_con">
        <div class="title">
          <h2 class="csdn-tracking-statistics" data-mod="popu_459" data-poputype="feed" data-feed-show="false" data-dsm="post">
              <a strategy="career" href="http://blog.csdn.net/GitChat/article/details/80276245" target="_blank">
                  只有程序员了解的9个真相              </a>
          </h2>
                    <div class="close_tag">
              <div class="unin_reason_dialog_wrapper">
                  <i class="icon-close"></i>
                  <div class="unin_reason_dialog">
                      <h3>选择理由，精准屏蔽</h3>
                      <ul>
                                                    <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a>推荐不准: 最新文章</a>
                          </li>
                          <br/>
                                                    <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a> 旧闻、重复 </a>
                          </li>
                          <br/>
                          <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a> 内容质量差 </a>
                          </li>
                          <br/>
                      </ul>
                  </div>
              </div>
          </div>
                  </div> 
        <div class="summary oneline">
          来源 | 菜鸟教程对于相关的计算机和代码知识，通常说来程序员比一般人要了解得多，下面我将为大家揭晓一些业内人士不会诉诸于口的真相。真相＃1&ldquo;你所不知道的是，很多我们每天都...        </div>
          <dl class="list_userbar">

              <dt>
                  <a href="http://blog.csdn.net/GitChat" target="_blank" class="user_img">
                      <img src="//avatar.csdn.net/2/8/D/1_gitchat.jpg" alt="GitChat" title="GitChat">
                  </a>
              </dt>
              <dd class="name">
                  <a href="http://blog.csdn.net/GitChat" target="_blank">
                      GitChat技术杂谈                  </a>
              </dd>
              <div class="interval"></div>
              <dd class="time">
                3天前              </dd>
                                <div class="interval"></div>
                  <dd class="tag">
                      <a href="/nav/career" target="_blank">
                          程序人生                      </a>
                  </dd>
              
              <div class="interactive floatR">
                <!--阅读 begin-->
                <dd class="read_num">
                  <a href="http://blog.csdn.net/GitChat/article/details/80276245">
                    <span class="num">590</span>
                    <span class="text">阅读</span>
                  </a>
                </dd>
                <!--阅读 end-->
                
                <!--新增评论数+阅读 begin-->
                <div class="interval"></div>
                <dd class="common_num csdn-tracking-statistics tracking-click" data-poputype="feed" data-mod="popu_459">
                    <a strategy="career" href="http://blog.csdn.net/GitChat/article/details/80276245#comment_form" target="_blank">
                         <span class="text">评论</span>
                    </a>
                </dd>
                <!--新增评论数+阅读 end-->
              </div>
          </dl>
                </div>
    </li>
                <li class="clearfix" data-type="blog" data-id="80256715" shown-time="1526258961">
      <div class="list_con">
        <div class="title">
          <h2 class="csdn-tracking-statistics" data-mod="popu_459" data-poputype="feed" data-feed-show="false" data-dsm="post">
              <a strategy="recommend" href="http://blog.csdn.net/yssycz/article/details/80256715" target="_blank">
                  最后1天，购票渠道即将关闭！Unite 2018开发者大会全日程公布              </a>
          </h2>
                    <div class="close_tag">
              <div class="unin_reason_dialog_wrapper">
                  <i class="icon-close"></i>
                  <div class="unin_reason_dialog">
                      <h3>选择理由，精准屏蔽</h3>
                      <ul>
                                                    <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a>推荐不准: 运营精选</a>
                          </li>
                          <br/>
                                                    <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a> 旧闻、重复 </a>
                          </li>
                          <br/>
                          <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a> 内容质量差 </a>
                          </li>
                          <br/>
                      </ul>
                  </div>
              </div>
          </div>
                  </div> 
        <div class="summary oneline">
          Unite Beijing 2018将于5月11日-13日在北京国家会议中心盛大召开！（网络购票渠道将于明日中午关闭，有需要的朋友抓紧购买，购票地址：大会官网）作为全球规模最大的Unity开发者聚会，历年Unite大会都成为开发者们获取Unity最新技术知识，交流开发经验，把握行业发展脉搏，体验全球前沿科技与高品质Made with Unity作品的绝佳平台。在过去的10年中，来自全球数以万计的开...        </div>
          <dl class="list_userbar">

              <dt>
                  <a href="http://blog.csdn.net/yssycz" target="_blank" class="user_img">
                      <img src="//avatar.csdn.net/5/8/2/1_yssycz.jpg" alt="yssycz" title="yssycz">
                  </a>
              </dt>
              <dd class="name">
                  <a href="http://blog.csdn.net/yssycz" target="_blank">
                      CSDN白岩                  </a>
              </dd>
              <div class="interval"></div>
              <dd class="time">
                4天前              </dd>
                                <div class="interval"></div>
                  <dd class="tag">
                      <a href="/nav/game" target="_blank">
                          游戏开发                      </a>
                  </dd>
              
              <div class="interactive floatR">
                <!--阅读 begin-->
                <dd class="read_num">
                  <a href="http://blog.csdn.net/yssycz/article/details/80256715">
                    <span class="num">1118</span>
                    <span class="text">阅读</span>
                  </a>
                </dd>
                <!--阅读 end-->
                
                <!--新增评论数+阅读 begin-->
                <div class="interval"></div>
                <dd class="common_num csdn-tracking-statistics tracking-click" data-poputype="feed" data-mod="popu_459">
                    <a strategy="recommend" href="http://blog.csdn.net/yssycz/article/details/80256715#comment_form" target="_blank">
                                                <span class="num">1</span> <span class="text">评论</span>
                    </a>
                </dd>
                <!--新增评论数+阅读 end-->
              </div>
          </dl>
                </div>
    </li>
                <li class="clearfix" data-type="blog" data-id="80288537" shown-time="1526258961">
      <div class="list_con">
        <div class="title">
          <h2 class="csdn-tracking-statistics" data-mod="popu_459" data-poputype="feed" data-feed-show="false" data-dsm="post">
              <a strategy="wechat" href="http://blog.csdn.net/MOY37RQW1JarN33BgZk/article/details/80288537" target="_blank">
                  新课上线|Python实现图片拼接与混合、XML-RPC文件共享程序等              </a>
          </h2>
                    <div class="close_tag">
              <div class="unin_reason_dialog_wrapper">
                  <i class="icon-close"></i>
                  <div class="unin_reason_dialog">
                      <h3>选择理由，精准屏蔽</h3>
                      <ul>
                                                    <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a>推荐不准: 业界最新</a>
                          </li>
                          <br/>
                                                    <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a> 旧闻、重复 </a>
                          </li>
                          <br/>
                          <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a> 内容质量差 </a>
                          </li>
                          <br/>
                      </ul>
                  </div>
              </div>
          </div>
                  </div> 
        <div class="summary oneline">
          关注「实验楼」，每天分享一个项目教程最近又上线了哪些新课程？快来看看吧～会员课一、《Python3 实现图片拼接与混合》课程来源：selfim课程简介：本课程主要是利用 ...        </div>
          <dl class="list_userbar">

              <dt>
                  <a href="http://blog.csdn.net/MOY37RQW1JarN33BgZk" target="_blank" class="user_img">
                      <img src="//avatar.csdn.net/E/D/3/1_moy37rqw1jarn33bgzk.jpg" alt="MOY37RQW1JarN33BgZk" title="MOY37RQW1JarN33BgZk">
                  </a>
              </dt>
              <dd class="name">
                  <a href="http://blog.csdn.net/MOY37RQW1JarN33BgZk" target="_blank">
                      实验楼v                  </a>
              </dd>
              <div class="interval"></div>
              <dd class="time">
                2天前              </dd>
                                <div class="interval"></div>
                  <dd class="tag">
                      <a href="/nav/ai" target="_blank">
                          人工智能                      </a>
                  </dd>
              
              <div class="interactive floatR">
                <!--阅读 begin-->
                <dd class="read_num">
                  <a href="http://blog.csdn.net/MOY37RQW1JarN33BgZk/article/details/80288537">
                    <span class="num">187</span>
                    <span class="text">阅读</span>
                  </a>
                </dd>
                <!--阅读 end-->
                
                <!--新增评论数+阅读 begin-->
                <div class="interval"></div>
                <dd class="common_num csdn-tracking-statistics tracking-click" data-poputype="feed" data-mod="popu_459">
                    <a strategy="wechat" href="http://blog.csdn.net/MOY37RQW1JarN33BgZk/article/details/80288537#comment_form" target="_blank">
                         <span class="text">评论</span>
                    </a>
                </dd>
                <!--新增评论数+阅读 end-->
              </div>
          </dl>
                </div>
    </li>
        <ins data-revive-zoneid='260' data-revive-id='8c38e720de1c90a6f6ff52f3f89c4d57'></ins></ins>        <li class="clearfix" data-type="blog" data-id="80276174" shown-time="1526258961">
      <div class="list_con">
        <div class="title">
          <h2 class="csdn-tracking-statistics" data-mod="popu_459" data-poputype="feed" data-feed-show="false" data-dsm="post">
              <a strategy="career" href="http://blog.csdn.net/heyc861221/article/details/80276174" target="_blank">
                  TIOBE和PYPL的5月编程语言排行榜：如果你只能学习一门语言，Python是最好的选择！...              </a>
          </h2>
                    <div class="close_tag">
              <div class="unin_reason_dialog_wrapper">
                  <i class="icon-close"></i>
                  <div class="unin_reason_dialog">
                      <h3>选择理由，精准屏蔽</h3>
                      <ul>
                                                    <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a>推荐不准: 最新文章</a>
                          </li>
                          <br/>
                                                    <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a> 旧闻、重复 </a>
                          </li>
                          <br/>
                          <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a> 内容质量差 </a>
                          </li>
                          <br/>
                      </ul>
                  </div>
              </div>
          </div>
                  </div> 
        <div class="summary oneline">
          图片来源：Avengers: Infinity War近日，TIOBE编程语言社区发布了 2018年 5月排行榜，Java、C、C ++ 三门编程语言依然占据前三，而Py...        </div>
          <dl class="list_userbar">

              <dt>
                  <a href="http://blog.csdn.net/heyc861221" target="_blank" class="user_img">
                      <img src="//avatar.csdn.net/6/F/2/1_heyc861221.jpg" alt="heyc861221" title="heyc861221">
                  </a>
              </dt>
              <dd class="name">
                  <a href="http://blog.csdn.net/heyc861221" target="_blank">
                      何永灿CSDN                  </a>
              </dd>
              <div class="interval"></div>
              <dd class="time">
                3天前              </dd>
                                <div class="interval"></div>
                  <dd class="tag">
                      <a href="/nav/career" target="_blank">
                          程序人生                      </a>
                  </dd>
              
              <div class="interactive floatR">
                <!--阅读 begin-->
                <dd class="read_num">
                  <a href="http://blog.csdn.net/heyc861221/article/details/80276174">
                    <span class="num">194</span>
                    <span class="text">阅读</span>
                  </a>
                </dd>
                <!--阅读 end-->
                
                <!--新增评论数+阅读 begin-->
                <div class="interval"></div>
                <dd class="common_num csdn-tracking-statistics tracking-click" data-poputype="feed" data-mod="popu_459">
                    <a strategy="career" href="http://blog.csdn.net/heyc861221/article/details/80276174#comment_form" target="_blank">
                         <span class="text">评论</span>
                    </a>
                </dd>
                <!--新增评论数+阅读 end-->
              </div>
          </dl>
                </div>
    </li>
                <li class="clearfix" data-type="blog" data-id="80276598" shown-time="1526258961">
      <div class="list_con">
        <div class="title">
          <h2 class="csdn-tracking-statistics" data-mod="popu_459" data-poputype="feed" data-feed-show="false" data-dsm="post">
              <a strategy="wechat" href="http://blog.csdn.net/X8i0Bev/article/details/80276598" target="_blank">
                  在职业生涯里，有没有让你觉得最得意和最糟糕的事情？              </a>
          </h2>
                    <div class="close_tag">
              <div class="unin_reason_dialog_wrapper">
                  <i class="icon-close"></i>
                  <div class="unin_reason_dialog">
                      <h3>选择理由，精准屏蔽</h3>
                      <ul>
                                                    <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a>推荐不准: 业界最新</a>
                          </li>
                          <br/>
                                                    <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a> 旧闻、重复 </a>
                          </li>
                          <br/>
                          <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a> 内容质量差 </a>
                          </li>
                          <br/>
                      </ul>
                  </div>
              </div>
          </div>
                  </div> 
        <div class="summary oneline">
          曾做过这样的一个调查，在程序员的职业生涯里，有没有让你觉得最得意和最糟糕的事情？现整理和大家一起分享。01最糟糕的：进了软件外包公司，项目一个接着一个，总有做不完的项目。...        </div>
          <dl class="list_userbar">

              <dt>
                  <a href="http://blog.csdn.net/X8i0Bev" target="_blank" class="user_img">
                      <img src="//avatar.csdn.net/D/1/0/1_x8i0bev.jpg" alt="X8i0Bev" title="X8i0Bev">
                  </a>
              </dt>
              <dd class="name">
                  <a href="http://blog.csdn.net/X8i0Bev" target="_blank">
                      爱开发V                  </a>
              </dd>
              <div class="interval"></div>
              <dd class="time">
                2天前              </dd>
                                <div class="interval"></div>
                  <dd class="tag">
                      <a href="/nav/career" target="_blank">
                          程序人生                      </a>
                  </dd>
              
              <div class="interactive floatR">
                <!--阅读 begin-->
                <dd class="read_num">
                  <a href="http://blog.csdn.net/X8i0Bev/article/details/80276598">
                    <span class="num">485</span>
                    <span class="text">阅读</span>
                  </a>
                </dd>
                <!--阅读 end-->
                
                <!--新增评论数+阅读 begin-->
                <div class="interval"></div>
                <dd class="common_num csdn-tracking-statistics tracking-click" data-poputype="feed" data-mod="popu_459">
                    <a strategy="wechat" href="http://blog.csdn.net/X8i0Bev/article/details/80276598#comment_form" target="_blank">
                                                <span class="num">2</span> <span class="text">评论</span>
                    </a>
                </dd>
                <!--新增评论数+阅读 end-->
              </div>
          </dl>
                </div>
    </li>
                <li class="clearfix" data-type="blog" data-id="80276486" shown-time="1526258961">
      <div class="list_con">
        <div class="title">
          <h2 class="csdn-tracking-statistics" data-mod="popu_459" data-poputype="feed" data-feed-show="false" data-dsm="post">
              <a strategy="wechat" href="http://blog.csdn.net/dQCFKyQDXYm3F8rB0/article/details/80276486" target="_blank">
                  又一名逃犯在张学友演唱会被 AI 捕获，人送绰号&ldquo;热心歌神张先生&rdquo;              </a>
          </h2>
                    <div class="close_tag">
              <div class="unin_reason_dialog_wrapper">
                  <i class="icon-close"></i>
                  <div class="unin_reason_dialog">
                      <h3>选择理由，精准屏蔽</h3>
                      <ul>
                                                    <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a>推荐不准: 业界最新</a>
                          </li>
                          <br/>
                                                    <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a> 旧闻、重复 </a>
                          </li>
                          <br/>
                          <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a> 内容质量差 </a>
                          </li>
                          <br/>
                      </ul>
                  </div>
              </div>
          </div>
                  </div> 
        <div class="summary oneline">
          ﻿﻿作者 | 明 明出品 | AI 科技大本营（公众号ID：rgznai100）有人说，张学友是一个时代的象征，是一代人青春的记忆。90 后的营长现在相信了。据悉，先后有...        </div>
          <dl class="list_userbar">

              <dt>
                  <a href="http://blog.csdn.net/dQCFKyQDXYm3F8rB0" target="_blank" class="user_img">
                      <img src="//avatar.csdn.net/6/9/F/1_dqcfkyqdxym3f8rb0.jpg" alt="dQCFKyQDXYm3F8rB0" title="dQCFKyQDXYm3F8rB0">
                  </a>
              </dt>
              <dd class="name">
                  <a href="http://blog.csdn.net/dQCFKyQDXYm3F8rB0" target="_blank">
                      AI科技大本营                  </a>
              </dd>
              <div class="interval"></div>
              <dd class="time">
                2天前              </dd>
                                <div class="interval"></div>
                  <dd class="tag">
                      <a href="/nav/ai" target="_blank">
                          人工智能                      </a>
                  </dd>
              
              <div class="interactive floatR">
                <!--阅读 begin-->
                <dd class="read_num">
                  <a href="http://blog.csdn.net/dQCFKyQDXYm3F8rB0/article/details/80276486">
                    <span class="num">369</span>
                    <span class="text">阅读</span>
                  </a>
                </dd>
                <!--阅读 end-->
                
                <!--新增评论数+阅读 begin-->
                <div class="interval"></div>
                <dd class="common_num csdn-tracking-statistics tracking-click" data-poputype="feed" data-mod="popu_459">
                    <a strategy="wechat" href="http://blog.csdn.net/dQCFKyQDXYm3F8rB0/article/details/80276486#comment_form" target="_blank">
                         <span class="text">评论</span>
                    </a>
                </dd>
                <!--新增评论数+阅读 end-->
              </div>
          </dl>
                </div>
    </li>
                <li class="clearfix" data-type="blog" data-id="79185353" shown-time="1526258961">
      <div class="list_con">
        <div class="title">
          <h2 class="csdn-tracking-statistics" data-mod="popu_459" data-poputype="feed" data-feed-show="false" data-dsm="post">
              <a strategy="recommend" href="http://blog.csdn.net/jiangwei0910410003/article/details/79185353" target="_blank">
                  Android&quot;挂逼&quot;修练之行--微信小程序逆向辅助插件工具开发详解              </a>
          </h2>
                    <div class="close_tag">
              <div class="unin_reason_dialog_wrapper">
                  <i class="icon-close"></i>
                  <div class="unin_reason_dialog">
                      <h3>选择理由，精准屏蔽</h3>
                      <ul>
                                                    <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a>推荐不准: 运营精选</a>
                          </li>
                          <br/>
                                                    <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a> 旧闻、重复 </a>
                          </li>
                          <br/>
                          <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a> 内容质量差 </a>
                          </li>
                          <br/>
                      </ul>
                  </div>
              </div>
          </div>
                  </div> 
        <div class="summary oneline">
          一、前言之前一篇文章已经详细介绍了微信小程序包的格式，在之前文章中也了解到小程序包存放在沙盒目录，但是微信为了让小程序包安全就对文件名做了一个处理，导致我们很难找到对应的小程序对应的包文件，所以本文就来开发一个辅助插件，可以查看微信小程序的appid以及快速找到对应的小程序包文件，然后利用之前的解析工具直接本地解析程序包即可，下面就开始我们的表演吧！二、添加小程序菜单首先第一步还是国际惯例，我们如...        </div>
          <dl class="list_userbar">

              <dt>
                  <a href="http://blog.csdn.net/jiangwei0910410003" target="_blank" class="user_img">
                      <img src="//avatar.csdn.net/7/1/0/1_jiangwei0910410003.jpg" alt="jiangwei0910410003" title="jiangwei0910410003">
                  </a>
              </dt>
              <dd class="name">
                  <a href="http://blog.csdn.net/jiangwei0910410003" target="_blank">
                      尼古拉斯_赵四                  </a>
              </dd>
              <div class="interval"></div>
              <dd class="time">
                6天前              </dd>
                                <div class="interval"></div>
                  <dd class="tag">
                      <a href="/nav/mobile" target="_blank">
                          移动开发                      </a>
                  </dd>
              
              <div class="interactive floatR">
                <!--阅读 begin-->
                <dd class="read_num">
                  <a href="http://blog.csdn.net/jiangwei0910410003/article/details/79185353">
                    <span class="num">2436</span>
                    <span class="text">阅读</span>
                  </a>
                </dd>
                <!--阅读 end-->
                
                <!--新增评论数+阅读 begin-->
                <div class="interval"></div>
                <dd class="common_num csdn-tracking-statistics tracking-click" data-poputype="feed" data-mod="popu_459">
                    <a strategy="recommend" href="http://blog.csdn.net/jiangwei0910410003/article/details/79185353#comment_form" target="_blank">
                                                <span class="num">4</span> <span class="text">评论</span>
                    </a>
                </dd>
                <!--新增评论数+阅读 end-->
              </div>
          </dl>
                </div>
    </li>
                <li class="clearfix" data-type="blog" data-id="80276427" shown-time="1526258961">
      <div class="list_con">
        <div class="title">
          <h2 class="csdn-tracking-statistics" data-mod="popu_459" data-poputype="feed" data-feed-show="false" data-dsm="post">
              <a strategy="career" href="http://blog.csdn.net/P5dEyT322JACS/article/details/80276427" target="_blank">
                  雷军的留名，不是以程序员身份              </a>
          </h2>
                    <div class="close_tag">
              <div class="unin_reason_dialog_wrapper">
                  <i class="icon-close"></i>
                  <div class="unin_reason_dialog">
                      <h3>选择理由，精准屏蔽</h3>
                      <ul>
                                                    <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a>推荐不准: 最新文章</a>
                          </li>
                          <br/>
                                                    <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a> 旧闻、重复 </a>
                          </li>
                          <br/>
                          <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a> 内容质量差 </a>
                          </li>
                          <br/>
                      </ul>
                  </div>
              </div>
          </div>
                  </div> 
        <div class="summary oneline">
          （点击上方蓝字，快速关注我们）转自：刘韧（LiuRenNews），作者：刘韧本文首发于1997年《中国计算机报》雷军，1969 年 2 月 16 日出生于湖北省仙桃市；1...        </div>
          <dl class="list_userbar">

              <dt>
                  <a href="http://blog.csdn.net/P5dEyT322JACS" target="_blank" class="user_img">
                      <img src="//avatar.csdn.net/E/4/9/1_p5deyt322jacs.jpg" alt="P5dEyT322JACS" title="P5dEyT322JACS">
                  </a>
              </dt>
              <dd class="name">
                  <a href="http://blog.csdn.net/P5dEyT322JACS" target="_blank">
                      程序员的那些事_                  </a>
              </dd>
              <div class="interval"></div>
              <dd class="time">
                3天前              </dd>
                                <div class="interval"></div>
                  <dd class="tag">
                      <a href="/nav/career" target="_blank">
                          程序人生                      </a>
                  </dd>
              
              <div class="interactive floatR">
                <!--阅读 begin-->
                <dd class="read_num">
                  <a href="http://blog.csdn.net/P5dEyT322JACS/article/details/80276427">
                    <span class="num">298</span>
                    <span class="text">阅读</span>
                  </a>
                </dd>
                <!--阅读 end-->
                
                <!--新增评论数+阅读 begin-->
                <div class="interval"></div>
                <dd class="common_num csdn-tracking-statistics tracking-click" data-poputype="feed" data-mod="popu_459">
                    <a strategy="career" href="http://blog.csdn.net/P5dEyT322JACS/article/details/80276427#comment_form" target="_blank">
                         <span class="text">评论</span>
                    </a>
                </dd>
                <!--新增评论数+阅读 end-->
              </div>
          </dl>
                </div>
    </li>
        <ins data-revive-zoneid='261' data-revive-id='8c38e720de1c90a6f6ff52f3f89c4d57'></ins></ins>        <li class="clearfix" data-type="blog" data-id="80288448" shown-time="1526258961">
      <div class="list_con">
        <div class="title">
          <h2 class="csdn-tracking-statistics" data-mod="popu_459" data-poputype="feed" data-feed-show="false" data-dsm="post">
              <a strategy="wechat" href="http://blog.csdn.net/VucNdnrzk8iwX/article/details/80288448" target="_blank">
                  再思人机智能融合              </a>
          </h2>
                    <div class="close_tag">
              <div class="unin_reason_dialog_wrapper">
                  <i class="icon-close"></i>
                  <div class="unin_reason_dialog">
                      <h3>选择理由，精准屏蔽</h3>
                      <ul>
                                                    <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a>推荐不准: 业界最新</a>
                          </li>
                          <br/>
                                                    <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a> 旧闻、重复 </a>
                          </li>
                          <br/>
                          <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a> 内容质量差 </a>
                          </li>
                          <br/>
                      </ul>
                  </div>
              </div>
          </div>
                  </div> 
        <div class="summary oneline">
          【我们通常在部分信息的基础上做出决策，当我们得到更完整的信息时，我们会犹豫不前】一、引言&nbsp;&nbsp;&nbsp; 人机融合智能是一种新型智能形式，它不同于人的智能、也不同于人工智能，是一种...        </div>
          <dl class="list_userbar">

              <dt>
                  <a href="http://blog.csdn.net/VucNdnrzk8iwX" target="_blank" class="user_img">
                      <img src="//avatar.csdn.net/B/6/8/1_vucndnrzk8iwx.jpg" alt="VucNdnrzk8iwX" title="VucNdnrzk8iwX">
                  </a>
              </dt>
              <dd class="name">
                  <a href="http://blog.csdn.net/VucNdnrzk8iwX" target="_blank">
                      人机与认知实验室                  </a>
              </dd>
              <div class="interval"></div>
              <dd class="time">
                2天前              </dd>
                                <div class="interval"></div>
                  <dd class="tag">
                      <a href="/nav/ai" target="_blank">
                          人工智能                      </a>
                  </dd>
              
              <div class="interactive floatR">
                <!--阅读 begin-->
                <dd class="read_num">
                  <a href="http://blog.csdn.net/VucNdnrzk8iwX/article/details/80288448">
                    <span class="num">101</span>
                    <span class="text">阅读</span>
                  </a>
                </dd>
                <!--阅读 end-->
                
                <!--新增评论数+阅读 begin-->
                <div class="interval"></div>
                <dd class="common_num csdn-tracking-statistics tracking-click" data-poputype="feed" data-mod="popu_459">
                    <a strategy="wechat" href="http://blog.csdn.net/VucNdnrzk8iwX/article/details/80288448#comment_form" target="_blank">
                                                <span class="num">1</span> <span class="text">评论</span>
                    </a>
                </dd>
                <!--新增评论数+阅读 end-->
              </div>
          </dl>
                </div>
    </li>
                <li class="clearfix" data-type="blog" data-id="80288509" shown-time="1526258961">
      <div class="list_con">
        <div class="title">
          <h2 class="csdn-tracking-statistics" data-mod="popu_459" data-poputype="feed" data-feed-show="false" data-dsm="post">
              <a strategy="wechat" href="http://blog.csdn.net/sD7O95O/article/details/80288509" target="_blank">
                  潘正磊：再过三五年 AI会变成开发人员的基本概念              </a>
          </h2>
                    <div class="close_tag">
              <div class="unin_reason_dialog_wrapper">
                  <i class="icon-close"></i>
                  <div class="unin_reason_dialog">
                      <h3>选择理由，精准屏蔽</h3>
                      <ul>
                                                    <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a>推荐不准: 业界最新</a>
                          </li>
                          <br/>
                                                    <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a> 旧闻、重复 </a>
                          </li>
                          <br/>
                          <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a> 内容质量差 </a>
                          </li>
                          <br/>
                      </ul>
                  </div>
              </div>
          </div>
                  </div> 
        <div class="summary oneline">
          在微软Build 2018开发者大会上，微软公司全球开发平台事业部的资深副总裁潘正磊（Julia Liuson）接受了界面记者在内的采访。潘正磊在微软西雅图总部带领一千多...        </div>
          <dl class="list_userbar">

              <dt>
                  <a href="http://blog.csdn.net/sD7O95O" target="_blank" class="user_img">
                      <img src="//avatar.csdn.net/0/D/F/1_sd7o95o.jpg" alt="sD7O95O" title="sD7O95O">
                  </a>
              </dt>
              <dd class="name">
                  <a href="http://blog.csdn.net/sD7O95O" target="_blank">
                      dotNET跨平台                  </a>
              </dd>
              <div class="interval"></div>
              <dd class="time">
                2天前              </dd>
                                <div class="interval"></div>
                  <dd class="tag">
                      <a href="/nav/career" target="_blank">
                          程序人生                      </a>
                  </dd>
              
              <div class="interactive floatR">
                <!--阅读 begin-->
                <dd class="read_num">
                  <a href="http://blog.csdn.net/sD7O95O/article/details/80288509">
                    <span class="num">67</span>
                    <span class="text">阅读</span>
                  </a>
                </dd>
                <!--阅读 end-->
                
                <!--新增评论数+阅读 begin-->
                <div class="interval"></div>
                <dd class="common_num csdn-tracking-statistics tracking-click" data-poputype="feed" data-mod="popu_459">
                    <a strategy="wechat" href="http://blog.csdn.net/sD7O95O/article/details/80288509#comment_form" target="_blank">
                         <span class="text">评论</span>
                    </a>
                </dd>
                <!--新增评论数+阅读 end-->
              </div>
          </dl>
                </div>
    </li>
                <li class="clearfix" data-type="blog" data-id="80253809" shown-time="1526258961">
      <div class="list_con">
        <div class="title">
          <h2 class="csdn-tracking-statistics" data-mod="popu_459" data-poputype="feed" data-feed-show="false" data-dsm="post">
              <a strategy="recommend" href="http://blog.csdn.net/sunhf_csdn/article/details/80253809" target="_blank">
                  民生银行分布式NewSQL数据库实践              </a>
          </h2>
                    <div class="close_tag">
              <div class="unin_reason_dialog_wrapper">
                  <i class="icon-close"></i>
                  <div class="unin_reason_dialog">
                      <h3>选择理由，精准屏蔽</h3>
                      <ul>
                                                    <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a>推荐不准: 运营精选</a>
                          </li>
                          <br/>
                                                    <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a> 旧闻、重复 </a>
                          </li>
                          <br/>
                          <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a> 内容质量差 </a>
                          </li>
                          <br/>
                      </ul>
                  </div>
              </div>
          </div>
                  </div> 
        <div class="summary oneline">
          前言此前，金融信息化建设主要依托原有集中型 IT 架构进行维护扩展，系统规模及复杂程度呈指数级增长，各类瓶颈逐渐暴露，日益增长的数字金融需求同旧式的系统架构缺陷之间的矛盾愈加凸显。中国人民银行、中国银行保险监督管理委员会等金融监管部门逐渐推出分布式转型政策要求，金融企业开始兴起分布式转型浪潮。民生银行作为中国第一家非国有企业所有的银行以及中国领先的零售银行，管理的总资产为 3.2 万亿人民币，运营...        </div>
          <dl class="list_userbar">

              <dt>
                  <a href="http://blog.csdn.net/sunhf_csdn" target="_blank" class="user_img">
                      <img src="//avatar.csdn.net/E/0/9/1_sunhf_csdn.jpg" alt="sunhf_csdn" title="sunhf_csdn">
                  </a>
              </dt>
              <dd class="name">
                  <a href="http://blog.csdn.net/sunhf_csdn" target="_blank">
                      孙浩峰                  </a>
              </dd>
              <div class="interval"></div>
              <dd class="time">
                4天前              </dd>
                                <div class="interval"></div>
                  <dd class="tag">
                      <a href="/nav/db" target="_blank">
                          数据库                      </a>
                  </dd>
              
              <div class="interactive floatR">
                <!--阅读 begin-->
                <dd class="read_num">
                  <a href="http://blog.csdn.net/sunhf_csdn/article/details/80253809">
                    <span class="num">2603</span>
                    <span class="text">阅读</span>
                  </a>
                </dd>
                <!--阅读 end-->
                
                <!--新增评论数+阅读 begin-->
                <div class="interval"></div>
                <dd class="common_num csdn-tracking-statistics tracking-click" data-poputype="feed" data-mod="popu_459">
                    <a strategy="recommend" href="http://blog.csdn.net/sunhf_csdn/article/details/80253809#comment_form" target="_blank">
                                                <span class="num">1</span> <span class="text">评论</span>
                    </a>
                </dd>
                <!--新增评论数+阅读 end-->
              </div>
          </dl>
                </div>
    </li>
                <li class="clearfix" data-type="blog" data-id="80276397" shown-time="1526258961">
      <div class="list_con">
        <div class="title">
          <h2 class="csdn-tracking-statistics" data-mod="popu_459" data-poputype="feed" data-feed-show="false" data-dsm="post">
              <a strategy="career" href="http://blog.csdn.net/tTU1EvLDeLFq5btqiK/article/details/80276397" target="_blank">
                  没有基础半路学编程，靠谱吗？              </a>
          </h2>
                    <div class="close_tag">
              <div class="unin_reason_dialog_wrapper">
                  <i class="icon-close"></i>
                  <div class="unin_reason_dialog">
                      <h3>选择理由，精准屏蔽</h3>
                      <ul>
                                                    <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a>推荐不准: 最新文章</a>
                          </li>
                          <br/>
                                                    <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a> 旧闻、重复 </a>
                          </li>
                          <br/>
                          <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a> 内容质量差 </a>
                          </li>
                          <br/>
                      </ul>
                  </div>
              </div>
          </div>
                  </div> 
        <div class="summary oneline">
          1、如果你没有去做，是不会知道自己能不能成为大牛的。2、学习是一辈子的事情，哪里来的半路出家？25岁学编程，35岁的时候你就是有10年编程经验的人。3、在互联网时代，随处...        </div>
          <dl class="list_userbar">

              <dt>
                  <a href="http://blog.csdn.net/tTU1EvLDeLFq5btqiK" target="_blank" class="user_img">
                      <img src="//avatar.csdn.net/6/F/5/1_ttu1evldelfq5btqik.jpg" alt="tTU1EvLDeLFq5btqiK" title="tTU1EvLDeLFq5btqiK">
                  </a>
              </dt>
              <dd class="name">
                  <a href="http://blog.csdn.net/tTU1EvLDeLFq5btqiK" target="_blank">
                      代码技巧                  </a>
              </dd>
              <div class="interval"></div>
              <dd class="time">
                3天前              </dd>
                                <div class="interval"></div>
                  <dd class="tag">
                      <a href="/nav/career" target="_blank">
                          程序人生                      </a>
                  </dd>
              
              <div class="interactive floatR">
                <!--阅读 begin-->
                <dd class="read_num">
                  <a href="http://blog.csdn.net/tTU1EvLDeLFq5btqiK/article/details/80276397">
                    <span class="num">210</span>
                    <span class="text">阅读</span>
                  </a>
                </dd>
                <!--阅读 end-->
                
                <!--新增评论数+阅读 begin-->
                <div class="interval"></div>
                <dd class="common_num csdn-tracking-statistics tracking-click" data-poputype="feed" data-mod="popu_459">
                    <a strategy="career" href="http://blog.csdn.net/tTU1EvLDeLFq5btqiK/article/details/80276397#comment_form" target="_blank">
                         <span class="text">评论</span>
                    </a>
                </dd>
                <!--新增评论数+阅读 end-->
              </div>
          </dl>
                </div>
    </li>
                <li class="clearfix" data-type="blog" data-id="80288567" shown-time="1526258961">
      <div class="list_con">
        <div class="title">
          <h2 class="csdn-tracking-statistics" data-mod="popu_459" data-poputype="feed" data-feed-show="false" data-dsm="post">
              <a strategy="wechat" href="http://blog.csdn.net/h8y0bDJVUkwE1LboZlE/article/details/80288567" target="_blank">
                  程序员都经历过的那些事              </a>
          </h2>
                    <div class="close_tag">
              <div class="unin_reason_dialog_wrapper">
                  <i class="icon-close"></i>
                  <div class="unin_reason_dialog">
                      <h3>选择理由，精准屏蔽</h3>
                      <ul>
                                                    <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a>推荐不准: 业界最新</a>
                          </li>
                          <br/>
                                                    <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a> 旧闻、重复 </a>
                          </li>
                          <br/>
                          <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a> 内容质量差 </a>
                          </li>
                          <br/>
                      </ul>
                  </div>
              </div>
          </div>
                  </div> 
        <div class="summary oneline">
          前段时间发现了一篇很有意思的文章，很形象地说明了程序员日常工作中遇到某些事情时的反应。按原作者的话来说，那就是：只要是程序员，看到下面这些表情图都会产生共鸣。注意：有的图...        </div>
          <dl class="list_userbar">

              <dt>
                  <a href="http://blog.csdn.net/h8y0bDJVUkwE1LboZlE" target="_blank" class="user_img">
                      <img src="//avatar.csdn.net/8/E/4/1_h8y0bdjvukwe1lbozle.jpg" alt="h8y0bDJVUkwE1LboZlE" title="h8y0bDJVUkwE1LboZlE">
                  </a>
              </dt>
              <dd class="name">
                  <a href="http://blog.csdn.net/h8y0bDJVUkwE1LboZlE" target="_blank">
                      爱编程_                  </a>
              </dd>
              <div class="interval"></div>
              <dd class="time">
                2天前              </dd>
                                <div class="interval"></div>
                  <dd class="tag">
                      <a href="/nav/career" target="_blank">
                          程序人生                      </a>
                  </dd>
              
              <div class="interactive floatR">
                <!--阅读 begin-->
                <dd class="read_num">
                  <a href="http://blog.csdn.net/h8y0bDJVUkwE1LboZlE/article/details/80288567">
                    <span class="num">266</span>
                    <span class="text">阅读</span>
                  </a>
                </dd>
                <!--阅读 end-->
                
                <!--新增评论数+阅读 begin-->
                <div class="interval"></div>
                <dd class="common_num csdn-tracking-statistics tracking-click" data-poputype="feed" data-mod="popu_459">
                    <a strategy="wechat" href="http://blog.csdn.net/h8y0bDJVUkwE1LboZlE/article/details/80288567#comment_form" target="_blank">
                         <span class="text">评论</span>
                    </a>
                </dd>
                <!--新增评论数+阅读 end-->
              </div>
          </dl>
                </div>
    </li>
                <li class="clearfix" data-type="blog" data-id="80276481" shown-time="1526258961">
      <div class="list_con">
        <div class="title">
          <h2 class="csdn-tracking-statistics" data-mod="popu_459" data-poputype="feed" data-feed-show="false" data-dsm="post">
              <a strategy="wechat" href="http://blog.csdn.net/dQCFKyQDXYm3F8rB0/article/details/80276481" target="_blank">
                  DeepMind 研发出类脑 AI 神经元，具备超强空间导航能力              </a>
          </h2>
                    <div class="close_tag">
              <div class="unin_reason_dialog_wrapper">
                  <i class="icon-close"></i>
                  <div class="unin_reason_dialog">
                      <h3>选择理由，精准屏蔽</h3>
                      <ul>
                                                    <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a>推荐不准: 业界最新</a>
                          </li>
                          <br/>
                                                    <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a> 旧闻、重复 </a>
                          </li>
                          <br/>
                          <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a> 内容质量差 </a>
                          </li>
                          <br/>
                      </ul>
                  </div>
              </div>
          </div>
                  </div> 
        <div class="summary oneline">
          作者 | DavidZh出品 | AI 科技大本营（公众号ID：rgznai100）Google 旗下人工智能公司 DeepMind 的研究人员最近在《自然》杂志上发表论...        </div>
          <dl class="list_userbar">

              <dt>
                  <a href="http://blog.csdn.net/dQCFKyQDXYm3F8rB0" target="_blank" class="user_img">
                      <img src="//avatar.csdn.net/6/9/F/1_dqcfkyqdxym3f8rb0.jpg" alt="dQCFKyQDXYm3F8rB0" title="dQCFKyQDXYm3F8rB0">
                  </a>
              </dt>
              <dd class="name">
                  <a href="http://blog.csdn.net/dQCFKyQDXYm3F8rB0" target="_blank">
                      AI科技大本营                  </a>
              </dd>
              <div class="interval"></div>
              <dd class="time">
                2天前              </dd>
                                <div class="interval"></div>
                  <dd class="tag">
                      <a href="/nav/ai" target="_blank">
                          人工智能                      </a>
                  </dd>
              
              <div class="interactive floatR">
                <!--阅读 begin-->
                <dd class="read_num">
                  <a href="http://blog.csdn.net/dQCFKyQDXYm3F8rB0/article/details/80276481">
                    <span class="num">87</span>
                    <span class="text">阅读</span>
                  </a>
                </dd>
                <!--阅读 end-->
                
                <!--新增评论数+阅读 begin-->
                <div class="interval"></div>
                <dd class="common_num csdn-tracking-statistics tracking-click" data-poputype="feed" data-mod="popu_459">
                    <a strategy="wechat" href="http://blog.csdn.net/dQCFKyQDXYm3F8rB0/article/details/80276481#comment_form" target="_blank">
                         <span class="text">评论</span>
                    </a>
                </dd>
                <!--新增评论数+阅读 end-->
              </div>
          </dl>
                </div>
    </li>
        <ins data-revive-zoneid='262' data-revive-id='8c38e720de1c90a6f6ff52f3f89c4d57'></ins></ins>        <li class="clearfix" data-type="blog" data-id="80276244" shown-time="1526258961">
      <div class="list_con">
        <div class="title">
          <h2 class="csdn-tracking-statistics" data-mod="popu_459" data-poputype="feed" data-feed-show="false" data-dsm="post">
              <a strategy="career" href="http://blog.csdn.net/xJ032w2j4cCjhOW8s8/article/details/80276244" target="_blank">
                  如何分辨一个公司是玩你还是爱你？              </a>
          </h2>
                    <div class="close_tag">
              <div class="unin_reason_dialog_wrapper">
                  <i class="icon-close"></i>
                  <div class="unin_reason_dialog">
                      <h3>选择理由，精准屏蔽</h3>
                      <ul>
                                                    <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a>推荐不准: 最新文章</a>
                          </li>
                          <br/>
                                                    <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a> 旧闻、重复 </a>
                          </li>
                          <br/>
                          <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a> 内容质量差 </a>
                          </li>
                          <br/>
                      </ul>
                  </div>
              </div>
          </div>
                  </div> 
        <div class="summary oneline">
          热文导读 |&nbsp;点击标题阅读如何进阶成为Android架构师？吊炸天！74款APP完整源码！程序员如何进阶成为大神？转载自：http://www.instrument.co...        </div>
          <dl class="list_userbar">

              <dt>
                  <a href="http://blog.csdn.net/xJ032w2j4cCjhOW8s8" target="_blank" class="user_img">
                      <img src="//avatar.csdn.net/7/0/B/1_xj032w2j4ccjhow8s8.jpg" alt="xJ032w2j4cCjhOW8s8" title="xJ032w2j4cCjhOW8s8">
                  </a>
              </dt>
              <dd class="name">
                  <a href="http://blog.csdn.net/xJ032w2j4cCjhOW8s8" target="_blank">
                      Java和Android架构                  </a>
              </dd>
              <div class="interval"></div>
              <dd class="time">
                3天前              </dd>
                                <div class="interval"></div>
                  <dd class="tag">
                      <a href="/nav/career" target="_blank">
                          程序人生                      </a>
                  </dd>
              
              <div class="interactive floatR">
                <!--阅读 begin-->
                <dd class="read_num">
                  <a href="http://blog.csdn.net/xJ032w2j4cCjhOW8s8/article/details/80276244">
                    <span class="num">582</span>
                    <span class="text">阅读</span>
                  </a>
                </dd>
                <!--阅读 end-->
                
                <!--新增评论数+阅读 begin-->
                <div class="interval"></div>
                <dd class="common_num csdn-tracking-statistics tracking-click" data-poputype="feed" data-mod="popu_459">
                    <a strategy="career" href="http://blog.csdn.net/xJ032w2j4cCjhOW8s8/article/details/80276244#comment_form" target="_blank">
                         <span class="text">评论</span>
                    </a>
                </dd>
                <!--新增评论数+阅读 end-->
              </div>
          </dl>
                </div>
    </li>
                <li class="clearfix" data-type="blog" data-id="80288414" shown-time="1526258961">
      <div class="list_con">
        <div class="title">
          <h2 class="csdn-tracking-statistics" data-mod="popu_459" data-poputype="feed" data-feed-show="false" data-dsm="post">
              <a strategy="wechat" href="http://blog.csdn.net/tkkzc3E6s4Ou4/article/details/80288414" target="_blank">
                  从人脸识别到机器翻译：52个有用的机器学习和预测API              </a>
          </h2>
                    <div class="close_tag">
              <div class="unin_reason_dialog_wrapper">
                  <i class="icon-close"></i>
                  <div class="unin_reason_dialog">
                      <h3>选择理由，精准屏蔽</h3>
                      <ul>
                                                    <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a>推荐不准: 业界最新</a>
                          </li>
                          <br/>
                                                    <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a> 旧闻、重复 </a>
                          </li>
                          <br/>
                          <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a> 内容质量差 </a>
                          </li>
                          <br/>
                      </ul>
                  </div>
              </div>
          </div>
                  </div> 
        <div class="summary oneline">
          选自KDnuggets&nbsp;&nbsp;机器之心编译参与：吴攀人工智能正在成为新一代技术变革的基础技术，但从头开始为自己的应用和业务开发人工智能程序既成本高昂，且往往很难达到自己想要的...        </div>
          <dl class="list_userbar">

              <dt>
                  <a href="http://blog.csdn.net/tkkzc3E6s4Ou4" target="_blank" class="user_img">
                      <img src="//avatar.csdn.net/5/A/A/1_tkkzc3e6s4ou4.jpg" alt="tkkzc3E6s4Ou4" title="tkkzc3E6s4Ou4">
                  </a>
              </dt>
              <dd class="name">
                  <a href="http://blog.csdn.net/tkkzc3E6s4Ou4" target="_blank">
                      深度学习世界                  </a>
              </dd>
              <div class="interval"></div>
              <dd class="time">
                2天前              </dd>
                                <div class="interval"></div>
                  <dd class="tag">
                      <a href="/nav/ai" target="_blank">
                          人工智能                      </a>
                  </dd>
              
              <div class="interactive floatR">
                <!--阅读 begin-->
                <dd class="read_num">
                  <a href="http://blog.csdn.net/tkkzc3E6s4Ou4/article/details/80288414">
                    <span class="num">101</span>
                    <span class="text">阅读</span>
                  </a>
                </dd>
                <!--阅读 end-->
                
                <!--新增评论数+阅读 begin-->
                <div class="interval"></div>
                <dd class="common_num csdn-tracking-statistics tracking-click" data-poputype="feed" data-mod="popu_459">
                    <a strategy="wechat" href="http://blog.csdn.net/tkkzc3E6s4Ou4/article/details/80288414#comment_form" target="_blank">
                                                <span class="num">1</span> <span class="text">评论</span>
                    </a>
                </dd>
                <!--新增评论数+阅读 end-->
              </div>
          </dl>
                </div>
    </li>
                <li class="clearfix" data-type="blog" data-id="80276595" shown-time="1526258961">
      <div class="list_con">
        <div class="title">
          <h2 class="csdn-tracking-statistics" data-mod="popu_459" data-poputype="feed" data-feed-show="false" data-dsm="post">
              <a strategy="wechat" href="http://blog.csdn.net/Y0Q2T57s/article/details/80276595" target="_blank">
                  面试时，如何在1分钟内更好的展现自己？              </a>
          </h2>
                    <div class="close_tag">
              <div class="unin_reason_dialog_wrapper">
                  <i class="icon-close"></i>
                  <div class="unin_reason_dialog">
                      <h3>选择理由，精准屏蔽</h3>
                      <ul>
                                                    <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a>推荐不准: 业界最新</a>
                          </li>
                          <br/>
                                                    <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a> 旧闻、重复 </a>
                          </li>
                          <br/>
                          <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a> 内容质量差 </a>
                          </li>
                          <br/>
                      </ul>
                  </div>
              </div>
          </div>
                  </div> 
        <div class="summary oneline">
          多人的求职面试的过程中都会遇到这个问题：&nbsp;&ldquo;请做个自我介绍。&rdquo;有的人，可以口若悬河、妙语连珠讲3分钟，有的人，可能磕磕巴巴，讲了30秒，前者一定能胜过后者，然则未必，今天...        </div>
          <dl class="list_userbar">

              <dt>
                  <a href="http://blog.csdn.net/Y0Q2T57s" target="_blank" class="user_img">
                      <img src="//avatar.csdn.net/4/2/E/1_y0q2t57s.jpg" alt="Y0Q2T57s" title="Y0Q2T57s">
                  </a>
              </dt>
              <dd class="name">
                  <a href="http://blog.csdn.net/Y0Q2T57s" target="_blank">
                      java面试笔试                  </a>
              </dd>
              <div class="interval"></div>
              <dd class="time">
                2天前              </dd>
                                <div class="interval"></div>
                  <dd class="tag">
                      <a href="/nav/career" target="_blank">
                          程序人生                      </a>
                  </dd>
              
              <div class="interactive floatR">
                <!--阅读 begin-->
                <dd class="read_num">
                  <a href="http://blog.csdn.net/Y0Q2T57s/article/details/80276595">
                    <span class="num">592</span>
                    <span class="text">阅读</span>
                  </a>
                </dd>
                <!--阅读 end-->
                
                <!--新增评论数+阅读 begin-->
                <div class="interval"></div>
                <dd class="common_num csdn-tracking-statistics tracking-click" data-poputype="feed" data-mod="popu_459">
                    <a strategy="wechat" href="http://blog.csdn.net/Y0Q2T57s/article/details/80276595#comment_form" target="_blank">
                         <span class="text">评论</span>
                    </a>
                </dd>
                <!--新增评论数+阅读 end-->
              </div>
          </dl>
                </div>
    </li>
                <li class="clearfix" data-type="blog" data-id="80221780" shown-time="1526258961">
      <div class="list_con">
        <div class="title">
          <h2 class="csdn-tracking-statistics" data-mod="popu_459" data-poputype="feed" data-feed-show="false" data-dsm="post">
              <a strategy="recommend" href="http://blog.csdn.net/hollis_chuang/article/details/80221780" target="_blank">
                  Java Web应用的代码分层最佳实践。              </a>
          </h2>
                    <div class="close_tag">
              <div class="unin_reason_dialog_wrapper">
                  <i class="icon-close"></i>
                  <div class="unin_reason_dialog">
                      <h3>选择理由，精准屏蔽</h3>
                      <ul>
                                                    <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a>推荐不准: 运营精选</a>
                          </li>
                          <br/>
                                                    <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a> 旧闻、重复 </a>
                          </li>
                          <br/>
                          <li class="unin_item csdn-tracking-statistics" data-poputype="feed" data-feed-show="false" data-dsm="post" data-mod="popu_462">
                              <a> 内容质量差 </a>
                          </li>
                          <br/>
                      </ul>
                  </div>
              </div>
          </div>
                  </div> 
        <div class="summary oneline">
          代码分层，对于任何一个Java Web开发来说应该都不陌生。一个好的层次划分不仅可以能使代码结构更加清楚，还可以使项目分工更加明确，可读性大大提升，更加有利于后期的维护和升级。从另外一个角度来看，好的代码分层架构，应该是可以很好的匹配上单一职责原则的。这样就可以降低层与层之间的依赖，还能最大程度的复用各层的逻辑。本文就来介绍下Java Web项目的代码到底应该如何分层。三层架构在软件体系架构设计中...        </div>
          <dl class="list_userbar">

              <dt>
                  <a href="http://blog.csdn.net/hollis_chuang" target="_blank" class="user_img">
                      <img src="//avatar.csdn.net/1/8/2/1_hollis_chuang.jpg" alt="hollis_chuang" title="hollis_chuang">
                  </a>
              </dt>
              <dd class="name">
                  <a href="http://blog.csdn.net/hollis_chuang" target="_blank">
                      hollis_chuang                  </a>
              </dd>
              <div class="interval"></div>
              <dd class="time">
                6天前              </dd>
                                <div class="interval"></div>
                  <dd class="tag">
                      <a href="/nav/arch" target="_blank">
                          架构                      </a>
                  </dd>
              
              <div class="interactive floatR">
                <!--阅读 begin-->
                <dd class="read_num">
                  <a href="http://blog.csdn.net/hollis_chuang/article/details/80221780">
                    <span class="num">695</span>
                    <span class="text">阅读</span>
                  </a>
                </dd>
                <!--阅读 end-->
                
                <!--新增评论数+阅读 begin-->
                <div class="interval"></div>
                <dd class="common_num csdn-tracking-statistics tracking-click" data-poputype="feed" data-mod="popu_459">
                    <a strategy="recommend" href="http://blog.csdn.net/hollis_chuang/article/details/80221780#comment_form" target="_blank">
                                                <span class="num">2</span> <span class="text">评论</span>
                    </a>
                </dd>
                <!--新增评论数+阅读 end-->
              </div>
          </dl>
                </div>
    </li>
    
        <li class="tip_box clearfix">
        <button type="button" class="txt btn-feed-refresh">刚刚阅读在这里，点击刷新</button>
        <div class="read-here csdn-tracking-statistics" data-mod="popu_464" data-dsm="post">
            <a>刚刚阅读在这里，点击刷新</a>
        </div>
    </li>
</ul>
<div class="feed_loading">
    <img src="/images/feedLoading.gif" alt="I'm loading" title="I'm loading">
</div>            </main>
        <!DOCTYPE html>
<aside>
    <!-- 右侧轮播广告 begin -->
        <div class="slide-outer right_top" style="position:relative; z-index:998">
        <div class="box hot"> 
            <div adsid="home08a" class="swapbox1">
                <ins data-revive-zoneid="131" data-revive-id="8c38e720de1c90a6f6ff52f3f89c4d57"></ins>
            </div>
            <div adsid="home08b" class="swapbox2">
                <ins data-revive-zoneid="132" data-revive-id="8c38e720de1c90a6f6ff52f3f89c4d57"></ins>
            </div>
            <div adsid="home08c" class="swapbox3">
                <ins data-revive-zoneid="133" data-revive-id="8c38e720de1c90a6f6ff52f3f89c4d57"></ins>
            </div>
            <div adsid="home08d" class="swapbox4">
                <ins data-revive-zoneid="134" data-revive-id="8c38e720de1c90a6f6ff52f3f89c4d57"></ins>
            </div>
            <div adsid="home08e" class="swapbox5">
                <ins data-revive-zoneid="135" data-revive-id="8c38e720de1c90a6f6ff52f3f89c4d57"></ins>
            </div>
            <div adsid="home08f" class="swapbox6">
                <ins data-revive-zoneid="136" data-revive-id="8c38e720de1c90a6f6ff52f3f89c4d57"></ins>
            </div>      
        </div>
        <ul class="js-tagRoot">
        </ul>
        <img src="//img-ads.csdn.net/2016/201608021757063065.png" alt="" class="icon-ad">
    </div>
        <!-- 右侧轮播广告 end -->
    <div class="right_box">
        <h3 class="feed_new_tit">
            <span class="line"></span><span class="txt">今日推荐</span>
        </h3>
        <div class="feed_company csdn-tracking-statistics" data-mod="popu_474" data-dsm="post">
            <ul class="company_list">
                            <li>
                <div class="img_box"><a href="https://blog.csdn.net/blockchain_lemon/article/details/80267324" target="_blank"><img src="//csdnimg.cn/feed/20180511/23776aa54c17fa88a64d4d623fe0c877.png?x-oss-process=image/resize,h_64" alt=""></a></div>
                    <div class="content">
                      <h3 class="company_name"><a href="https://blog.csdn.net/blockchain_lemon/article/details/80267324"  target="_blank">区块链最新顶级论文曝光！来自欧密会上的5篇重磅</a></h3>
                                                                </div>
                </li>
                            <li>
                <div class="img_box"><a href="https://blog.csdn.net/blockchain_lemon/article/details/80267290" target="_blank"><img src="//csdnimg.cn/feed/20180511/931d3df11f1de63215591a6b62b1a380.png?x-oss-process=image/resize,h_64" alt=""></a></div>
                    <div class="content">
                      <h3 class="company_name"><a href="https://blog.csdn.net/blockchain_lemon/article/details/80267290"  target="_blank">北大赢得区块链LongHash大赛第一！正规军进场</a></h3>
                                                                </div>
                </li>
                            <li>
                <div class="img_box"><a href="https://www.tinymind.cn/competitions/41?from=home1" target="_blank"><img src="//csdnimg.cn/feed/20180504/9515c2e23a39b00d9bbff1bb12dabbf7.jpg?x-oss-process=image/resize,h_64" alt=""></a></div>
                    <div class="content">
                      <h3 class="company_name"><a href="https://www.tinymind.cn/competitions/41?from=home1"  target="_blank">优秀的人工智能开发者必须掌握的技能</a></h3>
                                                                </div>
                </li>
                            <li>
                <div class="img_box"><a href="https://blog.csdn.net/heyc861221/article/details/80276175" target="_blank"><img src="//csdnimg.cn/feed/20180511/4b8d59f919779094662156bbb2e6d176.jpg?x-oss-process=image/resize,h_64" alt=""></a></div>
                    <div class="content">
                      <h3 class="company_name"><a href="https://blog.csdn.net/heyc861221/article/details/80276175"  target="_blank">Python和R正强强联合，“谁更好”的争论即将终</a></h3>
                                                                </div>
                </li>
                            <li>
                <div class="img_box"><a href="https://blog.csdn.net/csdnnews/article/details/80268719" target="_blank"><img src="//csdnimg.cn/feed/20180511/a75466d993c476230b4f823ca90a5b71.png?x-oss-process=image/resize,h_64" alt=""></a></div>
                    <div class="content">
                      <h3 class="company_name"><a href="https://blog.csdn.net/csdnnews/article/details/80268719"  target="_blank">Google，一切皆为 AI！</a></h3>
                                                                    <p class="txt oneline">Google，一切皆为 AI！</p>
                                          </div>
                </li>
                            <li>
                <div class="img_box"><a href="https://blog.csdn.net/csdnnews/article/details/80268690" target="_blank"><img src="//csdnimg.cn/feed/20180511/a99e631372dedf17f0005bad87377c3e.png?x-oss-process=image/resize,h_64" alt=""></a></div>
                    <div class="content">
                      <h3 class="company_name"><a href="https://blog.csdn.net/csdnnews/article/details/80268690"  target="_blank">Windows、Linux、macOS 爆严重安全</a></h3>
                                                                </div>
                </li>
                            <li>
                <div class="img_box"><a href="https://blog.csdn.net/csdnsevenn/article/details/80225770" target="_blank"><img src="//csdnimg.cn/feed/20180508/cbb660e7c49852e147dc98f783f1efc4.png?x-oss-process=image/resize,h_64" alt=""></a></div>
                    <div class="content">
                      <h3 class="company_name"><a href="https://blog.csdn.net/csdnsevenn/article/details/80225770"  target="_blank">一个简单的区块链货币，python实现</a></h3>
                                                                </div>
                </li>
                            <li>
                <div class="img_box"><a href="https://blog.csdn.net/csdnsevenn/article/details/80237912" target="_blank"><img src="//csdnimg.cn/feed/20180508/6f3752025ec87e5b1aa0fcd0b6dee028.png?x-oss-process=image/resize,h_64" alt=""></a></div>
                    <div class="content">
                      <h3 class="company_name"><a href="https://blog.csdn.net/csdnsevenn/article/details/80237912"  target="_blank">程序员可以没钱，但不能不「骚」！</a></h3>
                                                                </div>
                </li>
                            <li>
                <div class="img_box"><a href="http://gitbook.cn/gitchat/column/5ad70dea9a722231b25ddbf8?utm_source=jr18051101" target="_blank"><img src="//csdnimg.cn/feed/20180511/f854160a3dfdcf14c6cf672680bed44f.jpg?x-oss-process=image/resize,h_64" alt=""></a></div>
                    <div class="content">
                      <h3 class="company_name"><a href="http://gitbook.cn/gitchat/column/5ad70dea9a722231b25ddbf8?utm_source=jr18051101"  target="_blank">机器学习极简入门课</a></h3>
                                                                    <p class="txt oneline">李烨 · 微软高级软件工程师</p>
                                          </div>
                </li>
                            <li>
                <div class="img_box"><a href="http://gitbook.cn/gitchat/series/5af40af938c1ac1d8df9e125?utm_source=jr18051102" target="_blank"><img src="//csdnimg.cn/feed/20180511/b50d0b72a5914f1ec679c26e8bee8d90.jpg?x-oss-process=image/resize,h_64" alt=""></a></div>
                    <div class="content">
                      <h3 class="company_name"><a href="http://gitbook.cn/gitchat/series/5af40af938c1ac1d8df9e125?utm_source=jr18051102"  target="_blank">Java 并发编程从入门到实践</a></h3>
                                                                    <p class="txt oneline">图文并茂、由浅入深的精选专题</p>
                                          </div>
                </li>
                            <li>
                <div class="img_box"><a href="https://edu.csdn.net/huiyiCourse/detail/740?utm_source=home4" target="_blank"><img src="//csdnimg.cn/feed/20180511/08f89f3942355f20506cec1465aa95b8.png?x-oss-process=image/resize,h_64" alt=""></a></div>
                    <div class="content">
                      <h3 class="company_name"><a href="https://edu.csdn.net/huiyiCourse/detail/740?utm_source=home4"  target="_blank">Python网络爬虫必学--Scrapy框架的使用</a></h3>
                                                                </div>
                </li>
                            <li>
                <div class="img_box"><a href="https://edu.csdn.net/topic/ai3?utm_source=home4" target="_blank"><img src="//csdnimg.cn/feed/20180511/1b5aa2605aa62b75170e6cb1e8de68fe.png?x-oss-process=image/resize,h_64" alt=""></a></div>
                    <div class="content">
                      <h3 class="company_name"><a href="https://edu.csdn.net/topic/ai3?utm_source=home4"  target="_blank">大学那点编程知识都还给老师了？仅需百元再学一遍</a></h3>
                                                                </div>
                </li>
                            <li>
                <div class="img_box"><a href="https://huiyi.csdn.net/activity/product/goods_list?project_id=3849" target="_blank"><img src="//csdnimg.cn/feed/20180511/9494353e0d07d53747c252d8ca3a3793.png?x-oss-process=image/resize,h_64" alt=""></a></div>
                    <div class="content">
                      <h3 class="company_name"><a href="https://huiyi.csdn.net/activity/product/goods_list?project_id=3849"  target="_blank">科大讯飞AIUI3.0发布会 5.17相约深圳</a></h3>
                                                                </div>
                </li>
                            <li>
                <div class="img_box"><a href="http://10086id.csdn.net/" target="_blank"><img src="//csdnimg.cn/feed/20180307/9b4ea6a8403891f274d3f8b714658744.png?x-oss-process=image/resize,h_64" alt=""></a></div>
                    <div class="content">
                      <h3 class="company_name"><a href="http://10086id.csdn.net/"  target="_blank">智能手机你个心机boy，不知不觉挖了这么多坑！</a></h3>
                                                                </div>
                </li>
                            <li>
                <div class="img_box"><a href="http://qualcomm.csdn.net/" target="_blank"><img src="//csdnimg.cn/feed/20180206/481f31224e31a114adbf35cbdde4b24b.png?x-oss-process=image/resize,h_64" alt=""></a></div>
                    <div class="content">
                      <h3 class="company_name"><a href="http://qualcomm.csdn.net/"  target="_blank">5G标准已经完成，下一步是什么</a></h3>
                                                                </div>
                </li>
                            <li>
                <div class="img_box"><a href="http://ibmuniversity.csdn.net/" target="_blank"><img src="//csdnimg.cn/feed/20180206/fef6fa64e5d526bc9bc9e1522b9d020d.png?x-oss-process=image/resize,h_64" alt=""></a></div>
                    <div class="content">
                      <h3 class="company_name"><a href="http://ibmuniversity.csdn.net/"  target="_blank">人工智能、机器学习和认知计算入门指南</a></h3>
                                                                </div>
                </li>
                        </ul>
            <div class="other_company clearfix">
                        <a href="http://baidu.csdn.net/"  target="_blank">百度技术专区</a>
                        <a href="http://intel.csdn.net/"  target="_blank">英特尔开发人员专区</a>
                        <a href="https://bss.csdn.net/m/topic/ucloud"  target="_blank">UCan下午茶 2018</a>
                        <a href="http://bss.csdn.net/m/topic/aruba"  target="_blank">Aruba技术白皮书</a>
                        <a href="http://aws.csdn.net/"  target="_blank">AWS中文技术专区</a>
                        <a href="http://powerlinux.csdn.net/"  target="_blank">PowerLinux技术社区</a>
                        <a href="http://primeton.csdn.net/"  target="_blank">普元云计算</a>
                        <a href="http://huawei.csdn.net/"  target="_blank">华为云计算</a>
                        <a href="http://g.csdn.net/5271587"  target="_blank">腾讯云技术社区</a>
                        </div>
        </div>
    </div>
            <div class="right_box csdn-tracking-statistics" data-mod="popu_470" data-dsm="post">
            <div class="feed_viewpoint" style="background-image: url(/images/viewpoint_bg.png)">
                <a href="http://blog.csdn.net/pk.html?id=10579" target="_blank">
                    <img src="/images/mod_viewpoint.png" class="viewpoint_img" alt="csdn_viewpoint" title="csdn_viewpoint">
                    <h3>开发应用在做登录产品选择上，是优先考虑安全问题还是便捷问题？</h3>
                </a>
            </div>
            <div class="feed_vote">
                <dl>
                    <dt>安全</dt>
                    <dd>77%</dd>
                </dl>
                <a type="button" class="btn btn-border-red btn-lg30" href="http://blog.csdn.net/pk.html?id=10579" target="_blank">投票参与</a>
                <dl>
                    <dt>便捷</dt>
                    <dd>23%</dd>
                </dl>
            </div>
            <ul class="feed_new_arrlist">
                <li class="clearfix">
                    <span class="arr"><i class="icon CSDN_iconfont Feed-arrowup"></i></span>
                    <span class="txt"><a href="http://blog.csdn.net/pk.html?id=10570" target="_blank">激光雷达与摄像头，未来哪种会成为自动驾驶的核心传感器呢？</a></span>
                </li>
                <li class="clearfix">
                    <span class="arr"><i class="icon CSDN_iconfont Feed-arrowup"></i></span>
                    <span class="txt"><a href="http://blog.csdn.net/pk.html?id=10568" target="_blank">又到一年跳槽季，你更看重什么样的公司？</a></span>
                </li>
            </ul>
        </div>
            <div class="right_box magazine_box">
        <h3 class="feed_new_tit">
            <span class="txt">《程序员》杂志</span>
            <div class="opt-box">
                <a class="carousel-control" href="#magzCarousel" role="button" data-slide="prev">
                    <svg width="16" height="16" xmlns="http://www.w3.org/2000/svg"><path d="M8 16A8 8 0 1 1 8 0a8 8 0 0 1 0 16zm3-11.5L9.5 3l-5 5 5 5 1.5-1.5L7.5 8 11 4.5z" fill-rule="evenodd"/></svg>
                </a>
                <a class="carousel-control" href="#magzCarousel" role="button" data-slide="next">
                    <svg width="16" height="16" xmlns="http://www.w3.org/2000/svg"><path d="M8 16A8 8 0 1 1 8 0a8 8 0 0 1 0 16zM5 4.5L8.5 8 5 11.5 6.5 13l5-5-5-5L5 4.5z" fill-rule="evenodd"/></svg>
                </a>
            </div>
            <a href="http://www.programmer.com.cn/" class="how_to" target="_blank">我要订阅</a>
        </h3>
        <div class="carousel_magazine_box slide" id="magzCarousel" data-ride="carousel">
            <div class="carousel-inner" role="listbox">
                                <div class="feed_devmagazine_box item carousel-item clearfix active">
                    <div class="img_box">
                        <a href="http://gitbook.cn/gitchat/geekbook/5a3c7879902f0f2223e2526d?utm_source=sy18030802" target="_blank">
                            <img src="//csdnimg.cn/feed/20180308/09a514f3769fffdc701c64cf58b74e6a.png" alt="AI 工程师职业指南【限时特惠中】">
                        </a>
                    </div>
                    <div class="content">
                        <h3 class="tit"><a href="http://gitbook.cn/gitchat/geekbook/5a3c7879902f0f2223e2526d?utm_source=sy18030802" target="_blank">AI 工程师职业指南【限时特惠中】</a></h3>
                        <p class="txt">我们请来 AI 技术一线的专家，请他们从实践的角度来解析 AI 领域各技术岗位的合格工程师都是怎样炼成的。</p>
                    </div>
                </div>
                                <div class="feed_devmagazine_box item carousel-item clearfix ">
                    <div class="img_box">
                        <a href="http://gitbook.cn/gitchat/geekbook/5a5c5e6a2be8c361148234e6?utm_source=sy18030102" target="_blank">
                            <img src="//csdnimg.cn/feed/20180301/e1dfe3f73feaf3884fa39c99d412c587.png" alt="人工智能学术前沿">
                        </a>
                    </div>
                    <div class="content">
                        <h3 class="tit"><a href="http://gitbook.cn/gitchat/geekbook/5a5c5e6a2be8c361148234e6?utm_source=sy18030102" target="_blank">人工智能学术前沿</a></h3>
                        <p class="txt">这个栏目将帮助大家筛选出人工智能和机器学习领域，每年各大顶级会议和研讨班上有意思的论文，解读出论文的核心思想，为精读提供阅读指导。</p>
                    </div>
                </div>
                                <div class="feed_devmagazine_box item carousel-item clearfix ">
                    <div class="img_box">
                        <a href="http://gitbook.cn/gitchat/geekbook/5a5eb07bdff55721bc1dcaee?utm_source=sy18030101" target="_blank">
                            <img src="//csdnimg.cn/feed/20180301/bd25fdc660dd7173d7619b5141c852fc.png" alt="深入浅出区块链">
                        </a>
                    </div>
                    <div class="content">
                        <h3 class="tit"><a href="http://gitbook.cn/gitchat/geekbook/5a5eb07bdff55721bc1dcaee?utm_source=sy18030101" target="_blank">深入浅出区块链</a></h3>
                        <p class="txt">本期我们梳理了2017年区块链发展现状，从关键技术原理与实际应用出发，带你深入浅出探索区块链技术的方方面面。</p>
                    </div>
                </div>
                                <div class="feed_devmagazine_box item carousel-item clearfix ">
                    <div class="img_box">
                        <a href="http://gitbook.cn/gitchat/geekbook/5a7fe8eb194d786ae0b18956?utm_source=sy18022802" target="_blank">
                            <img src="//csdnimg.cn/feed/20180213/5498c4fa03b53244787741b4402c706e.png" alt="《 程序员 2017 精华本 》         【新书上架 · 全年精粹尽览】">
                        </a>
                    </div>
                    <div class="content">
                        <h3 class="tit"><a href="http://gitbook.cn/gitchat/geekbook/5a7fe8eb194d786ae0b18956?utm_source=sy18022802" target="_blank">《 程序员 2017 精华本 》         【新书上架 · 全年精粹尽览】</a></h3>
                        <p class="txt">16个主题，200余篇文章，180万字——不容错过的前沿技术、工具尽在其中，亲历者领域案例剖析</p>
                    </div>
                </div>
                            </div>
        </div>
    </div>
        <!-- 右侧图片广告 -->
    <div class="right_extension slide-outer">
        <ins data-revive-zoneid="242" data-revive-id="8c38e720de1c90a6f6ff52f3f89c4d57"></ins>
    </div>
    <div class="fixed24">
                <div class="right_box">
            <h3 class="feed_new_tit">
                <span class="line"></span><span class="txt">活动日历</span>
            </h3>
            <div class="feed_activiey_calendar">
                <ul class="csdn-tracking-statistics" data-mod="popu_593" data-dsm="post">
                                    <li>
                        <div class="date">
                        <strong>17</strong>
                        <p class="month">05月</p></p>
                        </div>
                        <div class="content">
                        <h3 class="activity_name"><a href="https://huiyi.csdn.net/activity/product/goods_list?project_id=3849" target="_blank">科大讯飞 AI·飞无界新品发布会</a></h3>
                            <p class="status">深圳南山区Reborn755泛娱乐馆</p>
                        </div>
                    </li>
                                    <li>
                        <div class="date">
                        <strong>19</strong>
                        <p class="month">05月</p></p>
                        </div>
                        <div class="content">
                        <h3 class="activity_name"><a href="https://huiyi.csdn.net/activity/product/goods_list?project_id=3844" target="_blank">实战课程 | EOS开发快速入门指南</a></h3>
                            <p class="status">北京</p>
                        </div>
                    </li>
                                    <li>
                        <div class="date">
                        <strong>26</strong>
                        <p class="month">05月</p></p>
                        </div>
                        <div class="content">
                        <h3 class="activity_name"><a href="https://huiyi.csdn.net/activity/product/goods_list?project_id=3852" target="_blank">PDJ区块链技术实战提高课程（ETH方向）二期班</a></h3>
                            <p class="status">北京</p>
                        </div>
                    </li>
                                    <li>
                        <div class="date">
                        <strong>19</strong>
                        <p class="month">06月</p></p>
                        </div>
                        <div class="content">
                        <h3 class="activity_name"><a href="http://challenge.xfyun.cn/?ch=csdn" target="_blank">科大讯飞iFLYTEK AI开发者大赛，首次开放方言数据，百万奖金等你来。</a></h3>
                            <p class="status">线上</p>
                        </div>
                    </li>
                                </ul>
            </div>
        </div>
                <div class="persion_article"></div>
    </div>
</aside>
      </div>
    </div>
    <script src="//csdnimg.cn/public/common/libs/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    
    <script  src="//csdnimg.cn/asdf/async-1.0.1.js"></script>
</body>
<script src="//csdnimg.cn/asdf/tracking-1.0.1.js" type="text/javascript"></script>
<script language="javascript" type="text/javascript">
// Traffic Stats of the entire Web site By baidu
    var _hmt = _hmt || [];
    (function() {
        var hm = document.createElement("script");
        hm.src = "//hm.baidu.com/hm.js?6bcd52f51e9b3dce32bec4a3997715ac";
        var s = document.getElementsByTagName("script")[0];
        s.parentNode.insertBefore(hm, s);
    })();
// Traffic Stats of the entire Web site By baidu end
</script>

<script src='//csdnimg.cn/pubfooter/js/publib_footer-1.0.3.js?v201802070958' data-isfootertrack="false"></script>
<script src='/js/csdn_feed.min.js?1525925943' type='text/javascript'></script>
<script src='//sdk.appadhoc.com/ab.plus.js'></script>
<script>
    adhoc('init', {
    appKey: 'ADHOC_3f25bcb4-f154-4b7c-8a82-f79b81816578'
    })
</script>
<script src='//csdnimg.cn/public/common/gotop/js/goTop-v1.0.min.js?v20180305174820'></script>
</html>
