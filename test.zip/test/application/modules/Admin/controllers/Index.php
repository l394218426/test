<?php 
/**
* 
*/
class IndexController extends BaseController
{
	
	function init()
	{
		
	}


	//首页
	public function IndexAction()
	{

		$this->display('index');
	}


	//登陆
	public function LoginAction()
	{		
		$session = $this->Session();
		if($this->getRequest()->isPost())
		{
			$post = $this->getRequest()->getPost();
			$where = [ "user_name" =>$post['user_name']];
			$name = $post['user_name'];
			$pwd = md5($post['user_pwd']);
			$user = new UseriModel();
			$res = $user->get('*',$where);
	
			if($res==[])
			{
				$this->Jump("账号不存在",'login');die;
			}
			if($res['user_name'] == $name && $res['user_pwd'] == $pwd)
			{
				$session->set('data',$res);
				$this->Jump("登陆成功",'index');die;
			}
			else
			{

				$this->Jump("登陆失败（账号或者密码错误）",'login');die;
			}

		}
		else
		{

			$this->display("login");
		}

	}

	//博客添加

	public function BlogAction()
	{
		$cate = new CateModel();
		$blog = new BlogModel();
		if($this->getRequest()->isPost())
		{
			
			$post = $this->getRequest()->getPost();

			if($post['blog_name'] == '')
			{

				$this->Jump('请输入博客名称','blog');die;
			}  
			$img = $this->do_upload('blog_img');

			if($img  == false)
			{

				$this->Jump('图片不合法','blog');
			}

			$post['blog_img'] = $img;
			$post['blog_time'] = time();
			$res = $blog->insert($post);
			if($res)
			{

				$this->Jump('添加成功','blog');
			}
			else
			{

				$this->Jump('添加失败','blog');
			}

		}
		else
		{

			$data['data'] = $cate->select(["cate_name","cate_id"]);
	
			$this->getView()->assign($data);

			$this->display('blog');
		}
		

	}


	//博客展示
	public function BloglistAction()
	{	

		$blog = new BlogModel();
		$page = $this->get('page',1);
		$res = $this->Page($blog,$page,'blog',4);
		$this->display('blogList',$res);
	}


	//博客删除
	public function BlogdelAction()
	{
		$blog = new BlogModel();
		
		$id = $this->get('id','');
		
		if($id =='')
		{
			$this->Jump('网络连接超时','blog');die;
		}
		
		$where['blog_id'] = $id;

		$res = $blog->delete($where);
		
		if($res) 
		{

			$this->Jump('删除成功','blogList');
		}
		else
		{

			$this->Jump('删除失败','blogList');
		}

	}

	//日记添加
	public function DiaryaddAction()
	{
		$diary = new DiaryModel();
		$year = new YearModel();
		if($this->isPost())
		{
				$post = $this->post();
				$data['diary_year'] = $post['year'];
				$data['diary_date'] = $post['month']."月".$post['day']."日";
				$data['diary_name'] = $post['diary_name'];
				$data['status'] = $post['status'];
				$data['diary_desc'] = $post['diary_desc'];
				$img = $this->do_upload('diary_img');
				if($img  == false)
				{
				$this->Jump('图片不合法','diarylist');die;

				}
				
				$data['diary_img'] = $img;

				$res = $diary->insert($data);

				if($res)
				{
					
					$this->Jump('添加成功','diarylist');
				}
				else
				{

					$this->Jump('添加失败','diarylist');
				}
			
		}
		else
		{
			$res['data'] = $year->select('*');

			$this->display('diaryadd',$res);
		}
	}

	//日记展示
	public function DiarylistAction()
	{
		
		$diary = new DiaryModel();

		$page = $this->get('page',1);
		
		$join['[>]year'] = ['diary_year'=>'year_id'];  
		
		$res = $this->Page($diary,$page,'diary',4,$join);

		$this->display('diarylist',$res);
	}


	//日记删除
	public function DiarydelAction()
	{

		$diary = new DiaryModel();
		
		$id = $this->get('id','');
		
		if($id =='')
		{
			$this->Jump('网络连接超时');die;
		}
		
		$where['diary_id'] = $id;

		$res = $diary->delete($where);
		
		if($res) 
		{

			$this->Jump('删除成功','blogList');
		}
		else
		{

			$this->Jump('删除失败','bloglist');
		}
	}

	//状态修改
	public function UpstatusAction()
	{

		$diary = new DiaryModel();
		$status = $this->post('status');
		if($status==1)
		{
			$data['status'] = 0;
		}
		else
		{
			$data['status'] = 1;
		}
		$where['diary_id'] = $this->post('id');
		$res = $diary->update($data,$where);
		if($res)
		{

			echo 1;
		}
		else
		{
			echo 0;
		}

	}

	//即时即改内容
	public function SavedescAction()
	{	

		$diary = new DiaryModel();
		$data['diary_desc'] = $this->post('desc');
		$where['diary_id'] = $this->post('id');
		$res = $diary->update($data,$where);
		if($res)
		{

			echo 1;
		}
		else
		{
			echo 0;
		}

	}

	//即时即改标题
	public function SavenameAction()
	{	

		$diary = new DiaryModel();
		$data['diary_name'] = $this->post('desc');
		$where['diary_id'] = $this->post('id');
		$res = $diary->update($data,$where);
		if($res)
		{

			echo 1;
		}
		else
		{
			echo 0;
		}

	}


	//退出
	public function OutAction()
	{

		$this->Closesession();

		$this->jump('退出','login');
	}


	//跳转
	public function Jump($msg,$url)
	{
		
	
		echo  "<script>alert('$msg');location.href='?c=index&a={$url}&m=admin'</script>";
	}
	


	//图片上传

	public function do_upload($file_name,$path="uploads")
	{
		$fileInfo = $this->getRequest()->getFiles($file_name);

		$maxSize = 2097152; //判断上传图片最大值

		$allowExt=array('jpeg','jpg','png','gif','wbmp');//允许的类型
		
		$flag = true;

		if($fileInfo['error']==0)
		{

			if($fileInfo['size']>$maxSize) die('上传文件大小不符合规定');

			$ext = strtolower(pathinfo($fileInfo['name'],PATHINFO_EXTENSION));
	
			if (!in_array($ext,$allowExt)) exit('非法文件类型');

         	if (!is_uploaded_file($fileInfo['tmp_name'])) exit('文件不是通过HTTP POST方式上传的');
         	if($flag){
         	   if (@!getimagesize($fileInfo['tmp_name']))
            {
              exit('不是真正的图片类型');
            }
         	}

         	if (!file_exists($path))
          {
            mkdir($path,0777,true);
            chmod($path,0777);
          }
          //确保文件名唯一防止产生覆盖
          $nuiName=md5(uniqid(microtime(true),true)).'.'.$ext;

          $destination=$path.'/'.$nuiName;

          if (@move_uploaded_file($fileInfo['tmp_name'],$destination))
          {
            return $destination;
          }
          else
          {
            return 0;
          }
        }
        else
        { 
          return false;
          // $this->uploads_error($fileInfo['error']);//验证错误类型
        }
		}
		



}