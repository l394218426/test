<?php 	

/**
* 
*/
class TestModel extends Medooo
{
	
			public function hello()
			{
				echo "hello world";
			}
}