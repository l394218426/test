
<?php 
class SignController extends BaseController{

    function init()
    {
        $this->response = $this->getResponse();
        $this->response->setHeader('Conntent-Type','text/json','charset=utf-8');
    }

         //签到
    public function SignAction()
    {   
        $user = new SignUserModel();
        $log = new SignLogModel();
        $session = $this->session();
        if($this->isPost())
        {

            $this->post('sign_num','0');
            $where['user_id'] = $session['data']['user_id'];
            $arr = $user->get('*',$where);
            $data['sign_num'] = $arr['sign_num']+1;
            $res = $user->update($data,$where);
            if($res)
            {
                $this->AlertJump('签到成功','sign');
            }
        }
        else
        {

            if($session['data']!=[])
            {
                $data['data'] = $session['data']; 
                $this->display('sign',$data);
            }
            else
            {

                $this->display('sign');
            }
        }
    }

    // //登陆
    // public function LoginAction()
    // {
 
    //     if($this->isPost())
    //     {

    //     $user = new SignUserModel();
    //     $name = $this->post('user_name');
    //     $pwd = md5($this->post('user_pwd'));
    //     $where['user_name'] = $name;
    //     $res = $user->get('*',$where);
    //         if($res==[])
    //         {
    //             $this->AlertJump('账号名不存在','login');die;
    //         }
    //            if($res['user_name']==$name&&$res['user_pwd']==$pwd)
    //            {
        
    //                 $this->session('data',$res);
    //                 $this->AlertJump('登陆成功','sign');
    //            }
    //            else
    //            {

    //                 echo "失败";
    //            }
    //     }
    //     else
    //     {

    //         $this->display('login');
    //     }
    
    // }

    //注册
    public function AbstractAction()
    {
    $model = new UserModel();
    $time = $this->post('time');
    $rand = $this->post('rand');
    $token = $this->token;
   
    $sign = $this->post('sign');
    $sign2 = sha1(implode('',[$time.$rand.$token]));

    if($sign==$sign2)
    {
        $data = $this->post('data');
        //解密
        $encrypt = new Encrpty('394218426','asdfgkadjaksdjsa');
        $decrypt = $encrypt->decrypt($data);
        $name['user_name'] = $decrypt['user_name'];
        $res = $model->get('*',$name);
        if(!$res)
        {
            $result = $model ->insert($decrypt);
            if($result)
            {

                 $arr = [
                "code"=> "200",
                'msg'=> "注册成功",
                "data" =>[]
                ];  
            }
            else
            {
                 $arr = [
                 "code"=> "205",
                 'msg'=> "注册失败",
                 "data" =>[]
                 ];
            }
           
        
        }
        else
        {

            $arr = [
            "code"=> "202",
            'msg'=> "账号已存在",
            "data" =>[] 
        ];

        }
        
    }
    else
    {

         $arr = [
            "code"=> "500",
            'msg'=> "失败",
            "data" =>'不好意思你不是帅哥'
        ];
    }
    $this->response->setBody(json_encode($arr));

    // echo json_encode($arr);die;
    // var_dump($arr);die;


    // $this->display('abstract');
    }

    //登陆
     public function LoginAction()
    {
    $model = new UserModel();
    $time = $this->post('time');
    $rand = $this->post('rand');
    $token = $this->token;
    $encrypt = new Encrpty('394218426','asdfgkadjaksdjsa');
    $sign = $this->post('sign');
    $sign2 = sha1(implode('',[$time.$rand.$token]));

    if($sign==$sign2)
    {
        $data = $this->post('data');
        //解密
   
        $decrypt = $encrypt->decrypt($data);
        $name['user_name'] = $decrypt['user_name'];
        $res = $model->get('*',$name);
        if($res)
        {
           if($res['user_name']==$name['user_name'] && $res['user_pwd'] == $decrypt['user_pwd']){
                 
                 $arr = [
                "code"=> "200",
                'msg'=> "登陆成功",
                "data" =>[]
                ];  
           }
           else
           {

                  $arr = [
                 "code"=> "215",
                 'msg'=> "账号不存在",
                 "data" =>[]
                 ];
            
           }        
               
        }
        else
        {

            $arr = [
            "code"=> "215",
            'msg'=> "账号不存在",
            "data" =>[] 
        ];

        }
        
    }
    else
    {

         $arr = [
            "code"=> "500",
            'msg'=> "失败",
            "data" =>'不好意思你不是帅哥'
        ];
    }
    $this->response->setBody(json_encode($arr));

    // echo json_encode($arr);die;
    // var_dump($arr);die;


    // $this->display('abstract');
    }


    //用户列表接口
    public function UserListAction()
    {

    $model = new UserModel();
    $time = $this->post('time');
    $rand = $this->post('rand');
    $token = $this->token;
    $encrypt = new Encrpty('394218426','asdfgkadjaksdjsa');
    $sign = $this->post('sign');
    $sign2 = sha1(implode('',[$time.$rand.$token]));

        if($sign==$sign2)
        {

            $res = $model->select('*');
            if($res)
            {   
               
                $encrypt = $encrypt->encrypt($res);

                 $arr = [
                 "code"=> "200",
                 'msg'=> "成功",
                 "data" =>$encrypt
                    ]; 

            }
            else
            {
                $arr = [
                 "code"=> "500",
                 'msg'=> "失败",
                 "data" =>[]
                    ]; 
            }
        }
         $this->response->setBody(json_encode($arr));
    }

    //文章添加
    public function AddAction()
    {
        $blog = new BlogModel();
        $time = $this->post('time');
        $rand = $this->post('rand');
        $token = $this->token;
   
        $sign = $this->post('sign');
        $sign2 = sha1(implode('',[$time.$rand.$token]));
        
         if($sign==$sign2)
        {   
             $data = $this->post('data');
            //解密
            $encrypt = new Encrpty('394218426','asdfgkadjaksdjsa');
            $decrypt = $encrypt->decrypt($data);
            $where['blog_name'] = $decrypt['blog_name'];
            $res = $blog->get('*',$where);
            if(!$res)
            {
                if($blog->insert($decrypt))
                {
                  $arr = [
                 "code"=> "200",
                 'msg'=> "添加成功",
                 "data" =>[]
                    ];  
                }
                else
                {
                      $arr = [
                 "code"=> "202",
                 'msg'=> "添加失败",
                 "data" =>[]
                    ]; 
                }
               
            }
            else
            {

                 $arr = [
                 "code"=> "500",
                 'msg'=> "文章已存在",
                 "data" =>[]
                    ]; 
            }
        }
         $this->response->setBody(json_encode($arr));
    }

    //文章分页
    public function ListAction()
    {

        $blog = new BlogModel();
        $time = $this->post('time');
        $rand = $this->post('rand');
        $token = $this->token;
        $encrypt = new Encrpty('394218426','asdfgkadjaksdjsa');
        $sign = $this->post('sign');
        $sign2 = sha1(implode('',[$time.$rand.$token]));
         if($sign==$sign2)
        {   
            $page = $this->post('page');
            $page = $encrypt->decrypt($page);
            $res = $this->page($blog,$page,'blog','2');
            if($res)
            {
                $encrypt = $encrypt->encrypt($res);
                $arr = [
                 "code"=> "200",
                 'msg'=> "success",
                 "data" =>$encrypt
                    ]; 
            }else
            {
                $arr = [
                 "code"=> "202",
                 'msg'=> "数据异常",
                 "data" =>[]
                    ]; 
            }
        }
        else
        {

            $arr = [
                 "code"=> "500",
                 'msg'=> "非法请求",
                 "data" =>[]
                    ]; 
        }
         $this->response->setBody(json_encode($arr));

    }
       public function encrypt($data)
    
    {

        $this->iv=substr('21212313213132aaa1',0,16);

       // $res = openssl_encrypt($data,'AES-256-CBC',$this->key,0,$this->iv);
       $res = openssl_encrypt($data,'AES-256-CBC',$this->key,0,$this->iv);

       return $res;

     }

     public function decrypt($data)
     {
         $this->iv=substr('21212313213132aaa1',0,16);
         $res = openssl_decrypt($data,'AES-256-CBC',$this->key,0,$this->iv);
        return $res;
     }

}


