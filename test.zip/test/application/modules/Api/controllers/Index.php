<?php 
class IndexController extends BaseController{

		public function init()
		{

		}

		//首页
		public function IndexAction()
		{
			$blog = new BlogModel();
			$cate = new CateModel();
		$res['data'] = $blog->query("SELECT * FROM `blog` LEFT JOIN `cate` ON blog.blog_cate=cate.cate_id LIMIT 4 ")->fetchAll();

		$res['blog'] = $blog->query("SELECT * FROM `blog` LEFT JOIN `cate` ON blog.blog_cate=cate.cate_id WHERE blog_cate=1 LIMIT 4 ")->fetchAll();
		
		$res['yii'] = $blog->query("SELECT * FROM `blog` LEFT JOIN `cate` ON blog.blog_cate=cate.cate_id WHERE blog_cate=2 LIMIT 4 ")->fetchAll();
			$this->getView()->assign($res);
			$this->display("index");

		}

		//博客列表
		public function BlogAction()
		{
			$blog = new BlogModel();
			$page = $this->get('page',1);
		
			$res = $this->Page($blog,$page,"blog",4);
			$this->display('blog',$res);
		}

		//个人简介
		public function UserDescAction()
		{

			$this->getView()->display('/index/user_desc.phtml');
		}

		//时间线
		public function TimelineAction()
		{
			$diary = new DiaryModel();
			
			$year = new YearModel();
		
			$res['count'] = $year->count('year');

			$join['[>]year'] = ['diary_year'=>'year_id']; 

			$res['data'] = $diary->select($join,'*',['status'=>1]);

			$res['year'] = $year->select("*");
			
			$this->getView()->display('/index/time_line.phtml',$res);

		}

		//详情页面
		public function DetailAction()
		{

			
			$blog = new BlogModel();
			$cate = new CateModel();
			$len = $blog->count('blog');
			$id = $this->get('id','');
			if($id!=="")
			{
				
				$where['blog_id'] = $id;
			}
			
			if($id<=0)
			{
				$this->AlertJump('没有上一页了','detail');
			}
			else if($id>$len)
			{
				$this->AlertJump('没有下一页了','detail');
			}
			$res['blog'] = $blog->get('*',$where);

			$this->display('detail',$res);
		}


	   //留言
	   public function MsgAction()
	   {

	   		return $this->display('msg');
	   }

		//搜索

	   public function SearchAction()
	   {
	   		$blog = new BlogModel();
			$cate = new CateModel();
	   		$blog_name = $this->post('search','');
	   		$where["blog_name[~]"] = $blog_name;
	   		$len = $blog->count('blog',$where);
	   		$count = ceil($len/4);
	   		if($blog_name!="")
	   		{
	   			$res['data'] = $blog->select('*',$where);
	   			
	   			$res['count'] = $count;
            
           		$res['page'] = 1;
	   			$this->display('blog',$res);

	   		}
	   		else
	   		{
	   			$this->AlertJump('搜索内容为空','blog');
	   				
	   		}

	   		
	   }
}


