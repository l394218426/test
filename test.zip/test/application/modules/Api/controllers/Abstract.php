<?php 

 /**
 * 
 */
 class AbstractController extends BaseController{

  
    function init()
    {
        $this->response = $this->getResponse();
        $this->response->setHeader('Conntent-Type','text/json','charset=utf-8');
       

    }

//注册
    public function IndexAction()
    {

        $where['time'] = $this->strTime;
        $where['rand'] = $this->randNumber;
        $where['token'] = $this->token; 
        $sign = sha1(implode('',[$where['time'].$where['rand'].$where['token']]));
        $where['sign'] = $sign;


        $data = [
            "user_name"=>'3121',
            'user_pwd'=>'131111'
        ];
        $encrypt = new Encrpty('394218426','asdfgkadjaksdjsa');
        $where['data'] = $encrypt->encrypt($data);
       
        $res = $this->curlQuery('http://127.0.0.1/test/public/?c=sign&a=abstract&m=api','post',$where);
        // $data = $this->response;
        $data = json_decode($res,true);
         var_dump($data['msg']);die;

    // $this->display('index');
    }

    //登陆
    public function LoginAction()
    {
        $where['time'] = $this->strTime;
        $where['rand'] = $this->randNumber;
        $where['token'] = $this->token; 
        $sign = sha1(implode('',[$where['time'].$where['rand'].$where['token']]));
        $where['sign'] = $sign;


        $data = [
            "user_name"=>'3121',
            'user_pwd'=>'131111'
        ];
        $encrypt = new Encrpty('394218426','asdfgkadjaksdjsa');
        $where['data'] = $encrypt->encrypt($data);
       
        $res = $this->curlQuery('http://127.0.0.1/test/public/?c=sign&a=login&m=api','post',$where);

        // $data = $this->response;
        $data = json_decode($res,true);
         var_dump($data['msg']);die;
    }

    //用户列表接口

    public function UserListAction()
    {

        $where['time'] = $this->strTime;
        $where['rand'] = $this->randNumber;
        $where['token'] = $this->token; 
        $sign = sha1(implode('',[$where['time'].$where['rand'].$where['token']]));
        $encrypt = new Encrpty('394218426','asdfgkadjaksdjsa');
        $where['sign'] = $sign;
        $res = $this->curlQuery('http://127.0.0.1/test/public/?c=sign&a=UserList&m=api','post',$where);
        $data = json_decode($res,true);
        $arr = $encrypt->decrypt($data['data']);

         var_dump($arr);die;

    }

    //文章添加
    public function AddAction()
    {
        $where['time'] = $this->strTime;
        $where['rand'] = $this->randNumber;
        $where['token'] = $this->token; 
        $sign = sha1(implode('',[$where['time'].$where['rand'].$where['token']]));
        $encrypt = new Encrpty('394218426','asdfgkadjaksdjsa');
        $where['sign'] = $sign;
        $data = [
            'blog_name'=>'大苏打撒',
            'blog_desc'=>'dsadsadsadsadsadsadada',
            'blog_cate'=>'2'
        ];
        $where['data'] = $encrypt->encrypt($data);
        $res = $this->curlQuery('http://127.0.0.1/test/public/?c=sign&a=add&m=api','post',$where);
        // $data = $this->response;
        $data = json_decode($res,true);
         var_dump($data['msg']);die;

    }

    //文章列表
    public function ListAction()
    {

        $where['time'] = $this->strTime;
        $where['rand'] = $this->randNumber;
        $where['token'] = $this->token; 
        $sign = sha1(implode('',[$where['time'].$where['rand'].$where['token']]));
        $where['sign'] = $sign;
        $page = $this->post('page',1);
        $encrypt = new Encrpty('394218426','asdfgkadjaksdjsa');
        $where['page'] = $encrypt->encrypt($page);
        $res = $this->curlQuery('http://127.0.0.1/test/public/?c=sign&a=list&m=api','post',$where);

         $data = json_decode($res,true);
         if($data['code']==200)
         {

            $res = $encrypt->decrypt($data['data']);
            var_dump($res);die;
         }
        
    }


    // public function ApiAction()
    // {   

    //         $data = ['dsadsa'=>21312321,"2131"=>312321];
    //         $res = $this->encrypt(serialize($data));
    //         $data = $this->decrypt(($res));

    // }
            
    // public function encrypt($data)
    // {

    //     $this->iv=substr('21212313213132aaa1',0,16);

    //    $res = openssl_encrypt($data,'AES-256-CBC',$this->key,0,$this->iv);

    //    return $res;

    //  }

    //  public function decrypt($data)
    //  {
    //      $this->iv=substr('21212313213132aaa1',0,16);
    //      $res = unserialize(openssl_decrypt($data,'AES-256-CBC',$this->key,0,$this->iv));

    //     return $res;
    //  }


 }
