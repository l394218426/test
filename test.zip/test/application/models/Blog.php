<?php 
class BlogModel extends Medooo{
	 // public $dbName = 'youxiu';
	 public $_table = 'blog';
}
