<?php 
class QorderModel extends Medooo{
	 // public $dbName = 'youxiu';
	 public $_table = 'qorder';
}