<?php
class CateModel extends Medoo{
	 // public $dbName = 'youxiu';
	 public $_table = 'cate';
}
