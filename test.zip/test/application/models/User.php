<?php
class UserModel extends medooo{
	 // public $dbName = 'youxiu';
	 public $_table = 'user';
// private $_table='user';

public function show(){
$list=$this->select('*'
);
return $list;
	}
}
