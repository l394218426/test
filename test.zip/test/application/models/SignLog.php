<?php 
class SignLogModel extends Medooo{
	 // public $dbName = 'youxiu';
	 public $_table = 'sign_log';
}