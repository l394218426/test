<?php 
/**
* 
*/
class GoodsModel extends medooo
{
	
		public $_table = 'goods';
}