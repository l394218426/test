<?php 

/**
* 
*/
class UserLogModel extends Medooo
{
		public $_table = 'user_log';

		
}