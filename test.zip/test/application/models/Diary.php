<?php 
class DiaryModel extends Medooo{
	 // public $dbName = 'youxiu';
	 public $_table = 'diary';
}