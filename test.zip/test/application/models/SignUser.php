<?php 
class SignUserModel extends Medooo{
	 // public $dbName = 'youxiu';
	 public $_table = 'sign_user';
}