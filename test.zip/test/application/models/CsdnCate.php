<?php 
/**
	* 
	*/
	class CsdnCateModel extends Medooo
	{
		
		public $_table = 'csdn_cate';
	}	
