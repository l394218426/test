<?php 
class YearModel extends Medooo{
	 // public $dbName = 'youxiu';
	 public $_table = 'year';
}
