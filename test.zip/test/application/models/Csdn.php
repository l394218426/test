<?php 

/**
* 
*/
class CsdnModel extends Medoo
{
		public $_table = 'csdn';

		
}