<?php 

/**
	* 
	*/
	class UseriModel extends Medoo
	{
		
		public $_table = 'user_';
	}	