<?php 

/**
* 
*/


class Db extends Yaf_Bootstrap_Abstract
{
	public $dbName = '1510b';
	public $tableName = null;
	public $pdo; 
	public $dsn;
	public function __construct()
	{

		$this->dsn = "mysql:host=127.0.0.1;dbname=$this->dbName";
		$this->connect();
	}

	//私有的克隆方法
	private function __clone()
	{

	}

	//连接
	private function connect()
	{
		$this->pdo = new PDO($this->dsn,'root','root',array(PDO::ATTR_PERSISTENT => true) );//开启长连接
		$this->pdo->exec('set names utf8');
	}

	//获取数组键值
	private function getKeys($data)
	{
		$key = array_keys($data);
			$str='';
			foreach($key as $k => $v){
				$str.="`".$v."`,";
			}
			return trim($str,",");	

	}

	//获取数组值
	private function getValues($data)
	{
		$key = array_values($data);
			$str='';
			foreach($key as $k => $v){
				$str.="'".$v."',";
			}
			return trim($str,",");	

	}

	//获取条件
	private function get_where($w){
		if($w==null)
		{
			$where = '';
		}else if(is_string($w))
		{

			$where = ' where '.$w;
		}else if(is_array($w))
		{
			$arr = '';
			foreach ($w as $key => $val) {
				$arr .="`".$key."` = '".$val."' and ";	
			}
			$where =" WHERE ".trim($arr,' and ');
		}
		return $where;
	}

	//获取要查询的字段
	private function column($field){
			if(is_array($field)){
			$str="";

		foreach($field as $k=>$v){	
			$str.='`'.$v.'`,';
		}
			$field = trim ($str,',');
		}
			return $field;
		}

	//查询 多条
	public function findAll($column='*')
	{
	
		
			$column = $this->column($column);
			$sql = "SELECT $column FROM $this->tableName";
		 	$res = $this->pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
		                                                                                                                                                                                                                                                                                                                                                             
		 return $res;
	}


	//查询 单条
	public function findOne($w=null,$column='*')
	{
		
			$where = $this->get_where($w);;
			$column = $this->column($column);
			$sql = "SELECT $column FROM $this->tableName $where";
			$res = $this->pdo->query($sql)->fetch(PDO::FETCH_ASSOC);


	 	return $res;
	}

	//添加
	public function add($data)
	{
		
		$key = $this->getKeys($data);
		$val = $this->getValues($data);
		$sql = "INSERT INTO $this->tableName"."(".$key.") VALUES (".$val.")";
		$res = $this->exec($sql);
		if($res)
		{
			$result = $this->pdo->lastinsertid();
		}
		else
		{
			return false;
		}
		return $result;
	}


	//删除
	public function del($w)
	{
		
		$where = $this->get_where($w); 
		$sql = "DELETE FROM $this->tableName".$where;
		$res = $this->exec($sql);
		
		return $res;
	}


	//修改
	public function save($w,$arr)
	{
		$where = $this->get_where($w);
		$arr = $this->get_where($arr);
		$sql = "UPDATE $this->tableName SET $where " . $arr;
		$res = $this->exec($sql);

		return $res;
	} 
	//执行语句
	private function exec($sql)
	{
		
		$res = $this->pdo->exec($sql);
		if($res)
		{
			return 1;
		}
		else
		{
			return false;
		}
	}
}

