<?php

/**
 * @name Bootstrap
 * @author shine\hasee
 * @desc 所有在Bootstrap类中, 以_init开头的方法, 都会被Yaf调用,
 * @see http://www.php.net/manual/en/class.yaf-bootstrap-abstract.php
 * 这些方法, 都接受一个参数:Yaf_Dispatcher $dispatcher
 * 调用的次序, 和申明的次序相同
 */
class Bootstrap extends Yaf_Bootstrap_Abstract {

	public $config; 

    public function _initConfig() {
		//把配置保存起来
		$arrConfig = Yaf_Application::app()->getConfig();
		//注册配置项
		Yaf_Registry::set('config', $arrConfig);

	}

	public function _initPlugin(Yaf_Dispatcher $dispatcher) {
		//注册一个插件
		$objSamplePlugin = new SamplePlugin();
		$dispatcher->registerPlugin($objSamplePlugin);

	}

	public function _initRoute(Yaf_Dispatcher $dispatcher) {
	

	 //在这里注册自己的路由协议,默认使用简单路由
	 $router = Yaf_Dispatcher::getInstance()->getRouter(); 
	 // var_dump(Yaf_Registry::get("config")->routes);die;
	 $router->addConfig(Yaf_Registry::get("config")->routes);  
	 //在刚才的示例里添加上下面两行 

	 //简单路由
	 // $route = new Yaf_Route_Simple("m", "c", "a"); 
	 // $router->addRoute("simple", $route); 
	 
	 //rewrite 路由
	 // $route = new Yaf_Route_Rewrite('jiange/:ids/:sort',
	 // 	[
	 // 		'controller' => 'login',
	 // 		'action' => 'index'
	 // 	]
	 // );

  //   $router->addRoute('nidongde', $route);
	  //  $route = new Yaf_Route_Regex('#^/login/([^/])/([^/])#',['controller' => 'login',
	  //  'action' => 'index'],
	  //  [
	  //  //完成数字到字符变量的映射
	  //  	1 => 'ids',
	  //  	2 =>'sort'
	  //  ]);

   // $router->addRoute('product', $route);
	}

	
	public function _initView(Yaf_Dispatcher $dispatcher) {
		//在这里注册自己的view控制器，例如smarty,firekylin
	 Yaf_Dispatcher::getInstance()->autoRender(FALSE);
		
	}

	public function _initBaseController(Yaf_Dispatcher $dispatcher)
	{
	$base = Yaf_Loader::import(APPLICATION_PATH."/application/controllers/common/base.php" );
	$encrpty = Yaf_Loader::import(APPLICATION_PATH."/application/controllers/common/encrpty.php" );
	}

	public function _initDatabase() { 
		//关闭所有视图模版渲染

	}	
}
                                                                                                                                                                                     